(() => {
'use strict';
let snippets=[];
const refresh=()=>chrome.storage.local.get({snippets:[]}).then(r=>{snippets=Array.isArray(r.snippets)?r.snippets:[]});
refresh().catch(console.warn);
chrome.storage.onChanged.addListener((c,a)=>{if(a==='local'&&c.snippets)snippets=c.snippets.newValue||[]});
const simple='textarea,input:not([type]),input[type="text"],input[type="search"],input[type="email"],input[type="url"],input[type="tel"]';
function editor(target) {
  if(!(target instanceof Element))return null;
  if(target.matches(simple))return target;
  const rich=target.closest('[contenteditable]:not([contenteditable="false"]),[role="textbox"][contenteditable]');
  if(rich?.isContentEditable)return rich;
  if(target.isContentEditable)return target;
  return null;
}
function formatted(text) {
  const now=new Date();
  return String(text||'').replace(/\{(date|time|datetime|url|domain)\}/gi,(_,key)=>{
    const values={date:now.toLocaleDateString(),time:now.toLocaleTimeString(),
      datetime:now.toLocaleString(),url:location.href,domain:location.hostname};
    return values[key.toLowerCase()]??_;
  });
}
function match(before) {
  return snippets.filter(s=>typeof s?.shortcut==='string'&&s.shortcut&&
    before.toLowerCase().endsWith(s.shortcut.toLowerCase()))
    .sort((a,b)=>b.shortcut.length-a.shortcut.length)[0];
}
function setField(el,start,end,value) {
  const next=el.value.slice(0,start)+value+el.value.slice(end);
  const proto=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
  const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;
  if(setter)setter.call(el,next);else el.value=next;
  el.setSelectionRange(start+value.length,start+value.length);
  el.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,data:value,inputType:'insertReplacementText'}));
}
function richContext(root) {
  const sel=root.ownerDocument.getSelection();
  if(!sel?.rangeCount||!sel.isCollapsed)return null;
  const caret=sel.getRangeAt(0);
  if(!root.contains(caret.startContainer))return null;
  const beforeRange=root.ownerDocument.createRange();
  beforeRange.selectNodeContents(root);
  beforeRange.setEnd(caret.startContainer,caret.startOffset);
  return {caret,sel,before:beforeRange.toString()};
}
function precedingRange(root,caret,characters) {
  // Use a text-node iterator to handle markup inside rich editors.
  const walker=root.ownerDocument.createTreeWalker(root,NodeFilter.SHOW_TEXT);
  const nodes=[];let node;
  while((node=walker.nextNode()))nodes.push(node);
  const prefix=root.ownerDocument.createRange();
  prefix.selectNodeContents(root);
  prefix.setEnd(caret.startContainer,caret.startOffset);
  const prefixText=prefix.toString();
  const startIndex=prefixText.length-characters;
  if(startIndex<0)return null;
  let consumed=0;
  for(const n of nodes) {
    const end=consumed+n.length;
    if(startIndex>=consumed&&startIndex<end) {
      const range=root.ownerDocument.createRange();
      range.setStart(n,startIndex-consumed);
      range.setEnd(caret.startContainer,caret.startOffset);
      return range;
    }
    consumed=end;
  }
  return null;
}
function replaceRich(root,range,text) {
  root.focus();
  const sel=root.ownerDocument.getSelection();
  sel.removeAllRanges();sel.addRange(range);
  // execCommand triggers native editor input/undo in many ProseMirror and Lexical editors.
  let success=false;
  try{success=root.ownerDocument.execCommand('insertText',false,text)}catch(e){}
  if(!success) {
    range.deleteContents();
    const node=root.ownerDocument.createTextNode(text);
    range.insertNode(node);
    range.setStartAfter(node);range.collapse(true);
    sel.removeAllRanges();sel.addRange(range);
    root.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,data:text,inputType:'insertReplacementText'}));
  }
}
function expand(el) {
  if(el.matches(simple)) {
    if(typeof el.selectionStart!=='number'||el.selectionStart!==el.selectionEnd)return false;
    const pos=el.selectionStart,found=match(el.value.slice(0,pos));
    if(!found)return false;
    setField(el,pos-found.shortcut.length,pos,formatted(found.text)+' ');
    return true;
  }
  const ctx=richContext(el);
  if(!ctx)return false;
  const found=match(ctx.before);
  if(!found)return false;
  const range=precedingRange(el,ctx.caret,found.shortcut.length);
  if(!range)return false;
  replaceRich(el,range,formatted(found.text)+' ');
  return true;
}
function onSpace(event) {
  if(event.key!==' '||event.isComposing||event.ctrlKey||event.altKey||event.metaKey||event.defaultPrevented)return;
  const el=editor(event.target);
  if(!el)return;
  try {
    if(expand(el)) {event.preventDefault();event.stopImmediatePropagation();}
  } catch(e) {console.warn('Masoom Text Expander failed:',e);}
}
// Capture early, before React/ProseMirror/Lexical keyboard handlers.
document.addEventListener('keydown',onSpace,true);
chrome.runtime.onMessage.addListener(msg=>{
  if(msg?.type!=='INSERT_SNIPPET')return;
  const el=editor(document.activeElement);if(!el)return;
  const value=formatted(msg.snippet?.text);
  if(el.matches(simple)) {
    if(typeof el.selectionStart==='number')setField(el,el.selectionStart,el.selectionEnd,value);
  } else {
    const ctx=richContext(el);if(ctx)replaceRich(el,ctx.caret.cloneRange(),value);
  }
});
})();