const ids=['first','last','country','phone','address1','address2','region','county','city','postcode'];
const el=id=>document.getElementById(id);
const notice=msg=>{el('notice').textContent=msg};
el('parse').addEventListener('click',()=>{if(!el('raw').value.trim())return notice('Paste an address first.');const data=AddressParser.parse(el('raw').value);ids.forEach(id=>el(id).value=data[id]||'');el('review').hidden=false;notice('Address parsed. Review all fields carefully, especially address line 2, region, county and phone.');});
el('clear').addEventListener('click',()=>{el('raw').value='';ids.forEach(id=>el(id).value='');el('review').hidden=true;notice('Cleared.');});
el('fill').addEventListener('click',async()=>{
 const data=Object.fromEntries(ids.map(id=>[id,el(id).value.trim()]));
 if(!data.first||!data.address1||!data.postcode||!data.country)return notice('Missing required fields: first name, street address, postcode or country.');
 if(!/^([A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2})$/i.test(data.postcode)&&/^(united kingdom|uk)$/i.test(data.country))return notice('Check UK postcode format before filling.');
 try{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id||!/^https:\/\/([a-z0-9-]+\.)*aliexpress\.(com|us)\//i.test(tab.url||''))return notice('Open an AliExpress checkout page in the active tab first.');
 const res=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>({ready:document.readyState,checkout:/\/p\/trade\/confirm\.html/i.test(location.pathname),error:/oops! something went wrong|please try again later/i.test(document.body?.innerText||'')})});
 const state=res?.[0]?.result;
 if(!state?.checkout)return notice('Safety check: open the AliExpress checkout page before filling.');
 if(state.error)return notice('AliExpress checkout is showing its own error page. No fields were changed. Refresh checkout and try again after it loads.');
 if(state.ready==='loading')return notice('Checkout is still loading. Wait until the shipping address dialog appears.');
 await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content.js']});
 const msg=await chrome.tabs.sendMessage(tab.id,{type:'MASOOMDEV_FILL',data});
 notice(msg?.message||'No response from AliExpress form.');
 }catch(e){notice('Unable to fill this page: '+e.message+'\nTry refreshing AliExpress checkout and reopening the shipping address dialog.');}
});

// Payment details are kept in memory-backed extension session storage only.
// This survives panel removal/navigation, but not a browser restart.
const paymentSessionKey='masoomdevPaymentSessionV158';
const paymentIds=['cardNumber','cardName','cardCvv'];
let paymentRestoreDone=false;
let paymentSaveQueue=Promise.resolve();
const savePaymentSession=()=>{
 if(!paymentRestoreDone)return;
 const values=Object.fromEntries(paymentIds.map(id=>[id,el(id).value]));
 paymentSaveQueue=paymentSaveQueue.then(()=>chrome.storage.session.set({[paymentSessionKey]:values})).catch(()=>{});
};
(async()=>{
 try{
  const saved=(await chrome.storage.session.get(paymentSessionKey))[paymentSessionKey];
  if(saved)for(const id of paymentIds)if(typeof saved[id]==='string'&&!el(id).value)el(id).value=saved[id];
 }catch(_){/* Session storage unavailable; the panel still works. */}
 finally{paymentRestoreDone=true;}
})();
paymentIds.forEach(id=>el(id).addEventListener('input',savePaymentSession));
el('fillPayment').addEventListener('click', async () => {
 const info = el('paymentNotice');
 const data = {number:el('cardNumber').value.replace(/\s+/g,''),name:el('cardName').value.trim(),cvv:el('cardCvv').value.trim()};
 if (!data.number || !data.name || !data.cvv) {info.textContent='Enter card number, cardholder name and CVV first.';return;}
 if (!/^\d{12,19}$/.test(data.number) || !/^\d{3,4}$/.test(data.cvv)) {info.textContent='Check card number (12–19 digits) and CVV (3–4 digits).';return;}
 try {
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id || !/^https:\/\/([a-z0-9-]+\.)*aliexpress\.(com|us)\//i.test(tab.url||'') || !/\/p\/trade\/confirm\.html/i.test(new URL(tab.url).pathname)) {info.textContent='Open AliExpress checkout first.';return;}
  // Check the top frame before attempting any fill. Do not submit payments.
  const results=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:async details => {
   const norm=x=>String(x||'').toLowerCase().replace(/\s+/g,' ').trim();
   const fields=[...document.querySelectorAll('input:not([type="hidden"]),textarea')].filter(e=>e.getClientRects().length>0&&!e.disabled&&getComputedStyle(e).visibility!=='hidden');
   const label=e=>{const a=[e.placeholder,e.name,e.id,e.getAttribute('autocomplete'),e.getAttribute('aria-label'),e.getAttribute('data-testid')];if(e.labels)a.push(...[...e.labels].map(x=>x.textContent));const ids=e.getAttribute('aria-labelledby');if(ids)for(const id of ids.split(/\s+/))a.push(document.getElementById(id)?.textContent);for(const p of [e.parentElement,e.parentElement?.parentElement])if(p)a.push(...[...p.querySelectorAll('label,span')].filter(x=>x.children.length===0&&x.textContent.length<45).slice(0,8).map(x=>x.textContent));return norm(a.filter(Boolean).join(' '));};
   const defs=[['Card number','number',/card.?number|card.?no\b|cc-number|cardnumber/i],['Cardholder name','name',/cardholder|card.?holder|name.?on.?card|cc-name/i],['CVV','cvv',/\bcvv\b|\bcvc\b|security.?code|card.?security|cc-csc/i]];
   const updated=[],missing=[];
   for(const [title,key,pattern] of defs){const matches=fields.filter(e=>pattern.test(label(e)));if(matches.length!==1){missing.push(title);continue;}const e=matches[0],value=details[key];try{e.focus();const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value').set.call(e,value);e.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:value}));e.dispatchEvent(new Event('change',{bubbles:true}));e.blur();if(e.value===value)updated.push(title);else missing.push(title);}catch(_){missing.push(title);}}
   return {updated,missing};
  },args:[data]});
  const filled=[...new Set(results.flatMap(r=>r.result?.updated||[]))];
  const missing=['Card number','Cardholder name','CVV'].filter(x=>!filled.includes(x));
  info.textContent=(filled.length?'Filled: '+filled.join(', ')+'. ':'No matching payment fields could be filled. ')+(missing.length?'Check manually: '+missing.join(', ')+'. ':'')+'No payment was submitted.';
 } catch(e) {info.textContent='Unable to access payment fields. AliExpress may use a protected payment iframe. Fill manually if necessary.';}
 // Retain all three values until the browser session ends, as requested.
});
