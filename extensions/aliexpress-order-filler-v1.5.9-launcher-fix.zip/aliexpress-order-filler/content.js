/* MasoomDev AliExpress Order Filler v1.4.1 — separate address mapping.
   Fill name/phone, put address line 2 ONLY in Apt/Suite/Unit, and
   put street + postcode ONLY in address search. Manual suggestion selection. */
if (!globalThis.__masoomdevFillerLoaded) {
  globalThis.__masoomdevFillerLoaded = true;
  chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (msg.type !== 'MASOOMDEV_FILL') return;
    fillAliExpress(msg.data).then(respond).catch(e => respond({message:'Autofill stopped: '+e.message}));
    return true;
  });
}
const normalize = s => String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
const isVisible = el => !!(el && el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden');
const labelOf = el => normalize([el.placeholder,el.getAttribute('aria-label'),el.name,el.id,el.closest('label')?.innerText,el.parentElement?.querySelector('label')?.innerText].join(' '));
function setNative(el, value, keepFocus=false) {
  el.focus();
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto,'value')?.set;
  if (setter) setter.call(el,String(value)); else el.value=String(value);
  el.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:String(value)}));
  el.dispatchEvent(new Event('change',{bubbles:true}));
  if (!keepFocus) el.blur();
}
function findDialog() {
  const all=[...document.querySelectorAll('[role="dialog"],[class*="modal"],[class*="dialog"]')]
    .filter(el=>isVisible(el) && /edit shipping address|contact information/i.test(el.innerText||'') && el.querySelectorAll('input').length>=5);
  all.sort((a,b)=>a.querySelectorAll('input').length-b.querySelectorAll('input').length);
  return all.pop() || document;
}
function sortedInputs(root) {
  return [...root.querySelectorAll('input')].filter(el=>isVisible(el)&&!el.disabled&&!['hidden','checkbox','radio'].includes(el.type))
    .sort((a,b)=>{const x=a.getBoundingClientRect(),y=b.getBoundingClientRect();return Math.abs(x.top-y.top)>12?x.top-y.top:x.left-y.left});
}
async function fillAliExpress(data) {
  if(!/\/p\/trade\/confirm\.html/i.test(location.pathname))return {message:'Safety check: not on AliExpress checkout. Nothing changed.'};
  if(/oops! something went wrong|please try again later/i.test(document.body?.innerText||''))return {message:'AliExpress checkout error detected. Nothing changed.'};
  const root=findDialog(), inputs=sortedInputs(root);
  if(inputs.length<6 || !/contact information/i.test(root.innerText||''))return {message:'Open the Edit shipping address dialog first. Nothing was changed.'};
  const search=inputs.find(el=>/search by postcode|search.*address|search by street/i.test(labelOf(el)));
  if(!search)return {message:'Address search field not found. Nothing was changed; please send a screenshot.'};
  const top=inputs.filter(el=>el.getBoundingClientRect().top<search.getBoundingClientRect().top-5);
  const first=top.find(el=>/first.?name|given.?name/.test(labelOf(el)))||top[0];
  const last=top.find(el=>/last.?name|surname|family.?name/.test(labelOf(el)))||top[1];
  const phone=top.find(el=>/phone|mobile|telephone/.test(labelOf(el)))||top.at(-1);
  const phoneValue=String(data.phone||'').replace(/\D/g,'').replace(/^44/,'').replace(/^0/,'');
  const fields=[['First name',first,data.first],['Last name',last,data.last],['Phone',phone,phoneValue]];
  const updated=[],failed=[];
  for(const [name,el,value] of fields){
    if(!value){failed.push(name+' missing');continue;}
    if(!el||el===search){failed.push(name+' field not found');continue;}
    setNative(el,value);
    if(normalize(el.value)===normalize(value))updated.push(name);else failed.push(name+' not verified');
  }
  // Address line 2 is a distinct field. Never concatenate it into the
  // address search, street, postcode, or any other input.
  const aptValue=String(data.address2||'').trim();
  if(aptValue){
    // AliExpress may use an input, textarea or a contenteditable control.
    // Labels can be sibling text, not attached through <label> or placeholder.
    const controls=[...root.querySelectorAll('input,textarea,[contenteditable="true"],[role="textbox"]')]
      .filter(el=>isVisible(el)&&!el.disabled&&el!==search&&!['hidden','checkbox','radio'].includes(el.type));
    const marker=/\b(?:apt|apartment|suite|unit|flat)\b/i;
    const descriptions=el=>{
      const id=el.id;
      const associated=id?[...root.querySelectorAll('label[for]')].filter(l=>l.htmlFor===id).map(l=>l.textContent):[];
      const aria=el.getAttribute('aria-labelledby');
      if(aria)for(const x of aria.split(/\s+/)){const node=document.getElementById(x);if(node)associated.push(node.textContent)}
      const result=[el.placeholder,el.getAttribute('aria-label'),el.getAttribute('data-placeholder'),el.name,...associated];
      // Common wrapper has the field caption as a sibling, not an HTML label.
      for(const parent of [el.parentElement,el.parentElement?.parentElement,el.parentElement?.parentElement?.parentElement]){
        if(!parent)continue;
        const text=[...parent.querySelectorAll('label,span,p,div')]
          .filter(n=>n.children.length===0&&n.textContent?.length<90)
          .map(n=>n.textContent.trim()).filter(Boolean).slice(0,24);
        result.push(...text);
      }
      return result.filter(Boolean).join(' ');
    };
    const below=controls.filter(el=>el.getBoundingClientRect().top>search.getBoundingClientRect().top+8);
    const candidates=below.filter(el=>marker.test(descriptions(el)));
    // If multiple fields share a broad wrapper, require an exact apt-like label.
    const exact=el=>/\b(?:apt\s*,?\s*suite\s*,?\s*unit|apt\s*\/\s*suite|apartment|address line 2|flat\s*\/\s*building)\b/i.test(descriptions(el));
    const selected=candidates.filter(exact);
    const apt=(selected.length===1?selected[0]:candidates.length===1?candidates[0]:null);
    if(apt){
      if(apt.matches('input,textarea'))setNative(apt,aptValue);
      else {apt.focus();apt.textContent=aptValue;apt.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:aptValue}));apt.dispatchEvent(new Event('change',{bubbles:true}));apt.blur();}
      const actual=apt.matches('input,textarea')?apt.value:apt.textContent;
      if(actual.trim()===aptValue)updated.push('Apt / suite / unit');
      else failed.push('Apt / suite / unit not verified');
    }else failed.push('Apt / suite / unit field not confidently detected — left unchanged');
  }
  const query=[String(data.address1||'').trim(),String(data.postcode||'').trim()].filter(Boolean).join('  ');
  if(!query){failed.push('Street/postcode missing');}
  else {
    setNative(search,query,true);
    // Keep focus and let AliExpress present its own address suggestions.
    if(normalize(search.value)===normalize(query))updated.push('Address search pasted');
    else failed.push('Address search not verified');
  }
  return {message:'Updated: '+(updated.join(', ')||'none')+'.\n'+(failed.length?'Check: '+failed.join(', ')+'.\n':'')+'Now SELECT the correct address suggestion yourself. Verify house number, postcode, region and county before Confirm. No address suggestion, Confirm or payment was clicked.'};
}
