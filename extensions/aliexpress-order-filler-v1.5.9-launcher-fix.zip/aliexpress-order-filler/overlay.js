/* MasoomDev in-page overlay: fixed-position UI, never changes checkout layout. */
(() => {
  if (globalThis.__masoomdevOverlayInstalled) return;
  globalThis.__masoomdevOverlayInstalled = true;
  const ID = 'masoomdev-order-filler-host';
  const save = state => { try { chrome.runtime.sendMessage({type:'MASOOMDEV_SET_STATE',state}).catch(()=>{}); } catch(e) {} };
  const current = () => {
    const host=document.getElementById(ID);
    return host ? {mode:host.dataset.mode || 'open', left:host.dataset.left || '', top:host.dataset.top || '', width:host.dataset.width || '', height:host.dataset.height || '', sizeVersion:3} : {mode:'closed'};
  };
  const open = (state={mode:'open'}) => {
    let host = document.getElementById(ID);
    if (host) { host.style.setProperty('display','block','important'); return host; }
    host = document.createElement('div');
    host.id = ID;
    host.dataset.mode=state.mode === 'minimized' ? 'minimized' : 'open';
    if (state.left) host.dataset.left=state.left;
    if (state.top) host.dataset.top=state.top;
    if (state.width) host.dataset.width=state.width;
    if (state.height) host.dataset.height=state.height;
    // Shadow DOM prevents AliExpress CSS from interfering with the panel.
    host.style.setProperty('all','initial','important');
    host.style.setProperty('position','fixed','important');
    host.style.setProperty('top','14px','important');
    host.style.setProperty('right','14px','important');
    host.style.setProperty('width',Math.min(Math.max(280,Number(state.width)||312),Math.max(220,innerWidth-16))+'px','important');
    host.style.setProperty('height',Math.min(Math.max(180,Number(state.height)||545),Math.max(120,innerHeight-16))+'px','important');
    host.style.setProperty('z-index','2147483647','important');
    host.style.setProperty('display','block','important');
    const shadow = host.attachShadow({mode:'closed'});
    const shell = document.createElement('div');
    shell.style.cssText = 'box-sizing:border-box;height:100%;width:100%;background:#fff;border:1px solid #d9d1ee;border-radius:13px;box-shadow:0 12px 48px #16102d55;overflow:hidden;display:flex;flex-direction:column;';
    const top = document.createElement('div');
    top.style.cssText='height:33px;flex-shrink:0;background:#4c2b9b;color:white;display:flex;align-items:center;justify-content:space-between;padding:0 10px;font:600 12px Arial,sans-serif;cursor:move;';
    const name = document.createElement('span');name.textContent='MasoomDev · AliExpress Order Filler';
    const controls = document.createElement('div');
    controls.style.cssText='display:flex;align-items:center;gap:6px;';
    const minimize = document.createElement('button');minimize.type='button';minimize.textContent='−';minimize.title='Minimize autofiller';minimize.setAttribute('aria-label','Minimize autofiller');
    minimize.style.cssText='border:0;border-radius:5px;background:#ffffff22;color:white;font:700 20px Arial;cursor:pointer;padding:0px 10px;line-height:25px;';
    const close = document.createElement('button');close.type='button';close.textContent='✕';close.title='Close autofiller';close.setAttribute('aria-label','Close autofiller');
    close.style.cssText='border:0;border-radius:5px;background:#ffffff22;color:white;font:700 17px Arial;cursor:pointer;padding:2px 9px;';
    close.addEventListener('click',()=>{save({mode:'closed'});host.remove();});
    controls.append(minimize,close);top.append(name,controls);
    const iframe = document.createElement('iframe');
    iframe.src=chrome.runtime.getURL('panel.html');
    iframe.title='AliExpress Order Filler';
    iframe.style.cssText='border:0;width:100%;flex:1;min-height:0;background:#fff;';
    shell.append(top,iframe);shadow.append(shell);
    let minimized=state.mode==='minimized';
    if(minimized){host.style.setProperty('height','33px','important');iframe.style.display='none';minimize.textContent='□';minimize.title='Restore autofiller';}
    if(state.left && state.top){host.style.setProperty('left',Math.max(0,Math.min(innerWidth-host.offsetWidth,Number(state.left)))+'px','important');host.style.setProperty('top',Math.max(0,Math.min(innerHeight-33,Number(state.top)))+'px','important');host.style.setProperty('right','auto','important');}
    minimize.addEventListener('click',()=>{
      minimized=!minimized;
      host.dataset.mode=minimized?'minimized':'open';
      save(current());
      host.style.setProperty('height',minimized?'33px':Math.min(Number(host.dataset.height)||545,Math.max(120,innerHeight-16))+'px','important');
      iframe.style.display=minimized?'none':'block';
      grip.style.display=minimized?'none':'block';
      minimize.textContent=minimized?'□':'−';
      minimize.title=minimized?'Restore autofiller':'Minimize autofiller';
      minimize.setAttribute('aria-label',minimize.title);
    });
    // Resize from bottom-right grip. Never resize AliExpress itself.
    const grip=document.createElement('div');
    grip.title='Drag to resize autofiller';
    grip.setAttribute('role','separator');
    grip.setAttribute('aria-label','Resize autofiller');
    grip.style.cssText='position:absolute;right:1px;bottom:1px;width:23px;height:23px;cursor:nwse-resize;z-index:3;touch-action:none;background:linear-gradient(135deg,transparent 0 55%,#a78bfa 55% 61%,transparent 61% 72%,#6d28d9 72% 79%,transparent 79%);';
    shell.style.position='relative';shell.append(grip);
    grip.style.display=minimized?'none':'block';
    let resizing=null;
    grip.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();const r=host.getBoundingClientRect();resizing={x:e.clientX,y:e.clientY,w:r.width,h:r.height};grip.setPointerCapture(e.pointerId);});
    grip.addEventListener('pointermove',e=>{if(!resizing)return;const r=host.getBoundingClientRect();const w=Math.max(Math.min(280,innerWidth),Math.min(innerWidth-r.left-8,resizing.w+e.clientX-resizing.x));const h=Math.max(Math.min(180,innerHeight),Math.min(innerHeight-r.top-8,resizing.h+e.clientY-resizing.y));host.style.setProperty('width',w+'px','important');host.style.setProperty('height',h+'px','important');});
    const finishResize=()=>{if(!resizing)return;resizing=null;const r=host.getBoundingClientRect();host.dataset.width=Math.round(r.width);host.dataset.height=Math.round(r.height);save(current());};
    grip.addEventListener('pointerup',finishResize);grip.addEventListener('pointercancel',finishResize);
    // Keep panel visible on smaller viewports / zoom changes.
    window.addEventListener('resize',()=>{if(!host.isConnected)return;const r=host.getBoundingClientRect();const w=Math.min(r.width,innerWidth-8);const h=Math.min(r.height,innerHeight-8);host.style.setProperty('width',Math.max(120,w)+'px','important');if(!minimized)host.style.setProperty('height',Math.max(80,h)+'px','important');if(r.left+w>innerWidth)host.style.setProperty('left',Math.max(0,innerWidth-w-4)+'px','important');if(r.top+33>innerHeight)host.style.setProperty('top',Math.max(0,innerHeight-37)+'px','important');});
    (document.documentElement || document.body).appendChild(host);
    // Drag only by the header, without touching checkout layout or inputs.
    let start=null;
    top.addEventListener('pointerdown', e=>{if(e.target===close||e.target===minimize||controls.contains(e.target))return;const r=host.getBoundingClientRect();start={x:e.clientX,y:e.clientY,left:r.left,top:r.top};top.setPointerCapture(e.pointerId);});
    top.addEventListener('pointermove',e=>{if(!start)return;const x=Math.max(0,Math.min(innerWidth-host.offsetWidth,start.left+e.clientX-start.x));const y=Math.max(0,Math.min(innerHeight-50,start.top+e.clientY-start.y));host.style.setProperty('left',x+'px','important');host.style.setProperty('top',y+'px','important');host.style.setProperty('right','auto','important');});
    top.addEventListener('pointerup',()=>{if(start){host.dataset.left=host.getBoundingClientRect().left;host.dataset.top=host.getBoundingClientRect().top;save(current());}start=null;});
    top.addEventListener('pointercancel',()=>start=null);
  };
  chrome.runtime.onMessage.addListener(msg=>{
    if(msg?.type!=='MASOOMDEV_TOGGLE_OVERLAY')return;
    const host=document.getElementById(ID);
    if(host){save({mode:'closed'});host.remove();}else{open();save(current());}
  });
  // Checkout-only launcher: independent of the panel, so Close does not remove it.
  // The icon is deliberately not shown on other AliExpress pages.
  const LAUNCHER_ID = 'masoomdev-order-filler-launcher';
  const isCheckout = () => location.hostname.toLowerCase().endsWith('aliexpress.com') || location.hostname.toLowerCase().endsWith('aliexpress.us')
    ? location.pathname.replace(/\/+$/, '') === '/p/trade/confirm.html' : false;
  function syncLauncher() {
    const existing = document.getElementById(LAUNCHER_ID);
    if (!isCheckout()) { if (existing) existing.remove(); return; }
    if (existing && existing.isConnected) return;
    if (existing) existing.remove();
    if (!document.documentElement) return;
    const launcher = document.createElement('div');
    launcher.id = LAUNCHER_ID;
    launcher.style.cssText = 'all:initial!important;position:fixed!important;right:14px!important;bottom:80px!important;width:48px!important;height:48px!important;z-index:2147483646!important;display:block!important;';
    const root = launcher.attachShadow({mode:'closed'});
    const button = document.createElement('button');
    button.type = 'button';
    button.title = 'Open AliExpress Order Filler';
    button.setAttribute('aria-label','Open AliExpress Order Filler');
    button.style.cssText = 'all:initial;box-sizing:border-box;display:flex;align-items:center;justify-content:center;width:48px;height:48px;border-radius:50%;background:#4c2b9b;box-shadow:0 5px 18px #28175c66;cursor:pointer;border:2px solid #fff;';
    const icon = document.createElement('img');
    icon.src = chrome.runtime.getURL('icons/icon48.png');
    icon.alt = '';
    icon.style.cssText = 'width:30px;height:30px;object-fit:contain;';
    button.appendChild(icon);
    // Use a direct click handler: no Chrome messaging round trip is required.
    // A stale/disconnected panel is removed before creating a fresh one.
    button.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
      try {
        let host = document.getElementById(ID);
        if (host && !host.isConnected) { host.remove(); host = null; }
        if (host && host.dataset.mode === 'minimized') {
          const state = current();
          state.mode = 'open';
          host.remove();
          open(state);
          save(current());
        } else if (host) {
          // Bring an existing panel back into view, even if the page changed its style.
          host.style.setProperty('display','block','important');
          host.style.setProperty('visibility','visible','important');
          host.style.setProperty('z-index','2147483647','important');
          const rect = host.getBoundingClientRect();
          if (rect.right < 40 || rect.left > innerWidth - 40 || rect.bottom < 33) {
            host.style.setProperty('left','auto','important');
            host.style.setProperty('right','14px','important');
            host.style.setProperty('top','14px','important');
          }
        } else {
          open({mode:'open'});
          save(current());
        }
      } catch (error) {
        console.error('[MasoomDev] Unable to open floating panel:', error);
        // A previously installed extension may have been reloaded without
        // refreshing this AliExpress tab. In that case its context is invalid.
        button.title = 'Refresh AliExpress page once after updating the extension';
      }
    });
    root.appendChild(button);
    document.documentElement.appendChild(launcher);
  }
  syncLauncher();
  window.addEventListener('popstate', syncLauncher);
  window.addEventListener('hashchange', syncLauncher);
  // AliExpress sometimes changes checkout routes without a document reload.
  setInterval(syncLauncher, 1500);
  // Restore only after a real document navigation. Never auto-open after manual close.
  chrome.runtime.sendMessage({type:'MASOOMDEV_GET_STATE'}).then(reply=>{
    if(document.getElementById(ID))return;
    const state=reply?.state;
    if(state && (state.mode==='open'||state.mode==='minimized'))open(state);
  }).catch(()=>{});
})();
