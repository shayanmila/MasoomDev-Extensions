AliExpress Order Filler — MasoomDev v1.5.0

INSTALL
1. Extract this ZIP to a permanent folder.
2. Open chrome://extensions, enable Developer Mode.
3. Remove the previous version, then Load unpacked and choose the aliexpress-order-filler folder.
4. Refresh the AliExpress checkout tab after installing.
5. Click the extension icon to open/close a floating panel inside the SAME tab.
6. Paste, Detect address, review and Fill as before. Select the correct AliExpress address suggestion yourself.

WHAT CHANGED
- Chrome Side Panel replaced by a fixed overlay within the AliExpress tab.
- Close button removes only the overlay; no checkout resize or page reload.
- Panel can be dragged by its header.
- Address parser and checkout form-filling code preserved from v1.4.2.
- No automatic order submission or payment.

TESTING
Static JavaScript/JSON and ZIP checks performed. Live checkout not tested.
If AliExpress still shows an error, test with other extensions disabled and share the exact sequence.

Version 1.5.1: Minimize (−) and restore (□) controls in the floating header. The iframe stays mounted, preserving form inputs.

v1.5.8: Default panel height 545px (as requested); width remains 312px. Previously saved dimensions reset once on upgrade.

1.5.9: Fixed checkout floating launcher opening/restoring the panel, improved visibility and offscreen recovery. Refresh existing checkout tabs after extension updates.
