// Per-tab floating panel state survives page navigation, without changing checkout layout.
const key = tabId => `masoomdev_overlay_tab_${tabId}`;
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (!sender.tab?.id || !msg || !['MASOOMDEV_GET_STATE','MASOOMDEV_SET_STATE'].includes(msg.type)) return;
  const k = key(sender.tab.id);
  if (msg.type === 'MASOOMDEV_GET_STATE') {
    chrome.storage.session.get(k).then(data => respond({state:(() => { const st=data[k] || {mode:'closed'}; if(st.sizeVersion !== 3) { delete st.width; delete st.height; st.sizeVersion=3; } return st; })()})).catch(()=>respond({state:{mode:'closed'}}));
  } else {
    const state = msg.state || {mode:'closed'};
    chrome.storage.session.set({[k]:state}).then(()=>respond({ok:true})).catch(()=>respond({ok:false}));
  }
  return true;
});
chrome.tabs.onRemoved.addListener(tabId => { chrome.storage.session.remove(key(tabId)).catch(()=>{}); });
chrome.action.onClicked.addListener(async tab => {
  if (!tab?.id || !/^https:\/\/([a-z0-9-]+\.)*aliexpress\.(com|us)\//i.test(tab.url || '')) return;
  try { await chrome.tabs.sendMessage(tab.id, {type:'MASOOMDEV_TOGGLE_OVERLAY'}); }
  catch(e) {
    try {
      await chrome.scripting.executeScript({target:{tabId:tab.id},files:['overlay.js']});
      await chrome.tabs.sendMessage(tab.id,{type:'MASOOMDEV_TOGGLE_OVERLAY'});
    } catch(ignored) { console.warn('Cannot open overlay on this page',ignored); }
  }
});
