/* Conservative heuristic parser: always requires human review. No remote calls. */
const AddressParser = (() => {
 const UK=/\b(?:GIR\s?0AA|(?:[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}))\b/i;
 const COUNTRY=/^(?:united kingdom|uk|great britain|england|scotland|wales|northern ireland|united states|usa|pakistan)$/i;
 const REGIONS=['England','Scotland','Wales','Northern Ireland'];
 const COUNTY=/\b(?:County Londonderry|Londonderry|County Antrim|County Armagh|County Down|County Fermanagh|County Tyrone|Greater Manchester|Greater London|East Sussex|West Sussex|North Yorkshire|South Yorkshire|West Yorkshire|East Yorkshire|Lancashire|Kent|Surrey|Essex|Hampshire|Devon|Cornwall|Berkshire|Oxfordshire|Cambridgeshire|Merseyside|West Midlands|East Midlands|Hertfordshire|Bedfordshire|Buckinghamshire|Nottinghamshire|Derbyshire|Leicestershire|Lincolnshire|Warwickshire|Worcestershire|Gloucestershire|Somerset|Dorset|Wiltshire|Suffolk|Norfolk|Staffordshire|Cheshire|Cumbria|Durham|Tyne and Wear|Northumberland|Shropshire|Herefordshire|East Riding of Yorkshire)\b/i;
 function parse(raw){
  let lines=raw.replace(/\r/g,'').split(/\n|\s*;\s*/).map(s=>s.trim()).filter(Boolean);
  const out={first:'',last:'',country:'United Kingdom',phone:'',address1:'',address2:'',region:'',county:'',city:'',postcode:''};
  const labeled={};const unlabelled=[];
  for(let line of lines){const m=line.match(/^(full\s*name|recipient|first\s*name|last\s*name|name|phone(?:\s*number)?|mobile|telephone|address(?:\s*line)?\s*[12]|street|flat|apartment|city|town|county|state|province|region|postcode|postal\s*code|zip(?:\s*code)?|country)\s*:\s*(.+)$/i);if(m)labeled[m[1].toLowerCase().replace(/\s+/g,' ')]=m[2].trim();else unlabelled.push(line)}
  const take=(...keys)=>{for(const k of keys)if(labeled[k])return labeled[k];return ''};
  const name=take('full name','recipient','name')||unlabelled.shift()||'';
  const parts=name.split(/\s+/);out.first=take('first name')||parts.shift()||'';out.last=take('last name')||parts.join(' ');
  out.phone=take('phone','phone number','mobile','telephone');out.postcode=take('postcode','postal code','zip','zip code');out.country=take('country')||'United Kingdom';out.region=take('region','state','province');out.county=take('county');out.city=take('city','town');out.address1=take('address 1','address line 1','street');out.address2=take('address 2','address line 2','flat','apartment');
  let remaining=[];
  for(const l of unlabelled){
   if(COUNTRY.test(l)){out.country=l;continue}
   const pm=l.match(UK);if(pm){out.postcode ||= pm[0].toUpperCase().replace(/\s+/g,'');out.postcode=out.postcode.replace(/^(.*?)(\d[A-Z]{2})$/,'$1 $2');let rest=l.replace(pm[0],'').replace(/[,\s]+$/,'').trim();const countyMatch=rest.match(COUNTY);if(countyMatch){out.county ||= countyMatch[0];rest=rest.replace(countyMatch[0],'').replace(/[,\s]+$/,'').trim()}if(rest)remaining.push(rest);continue}
   if(/^\+?[\d\s()\-.]{8,}$/.test(l)){out.phone ||= l;continue}
   if(REGIONS.some(r=>r.toLowerCase()===l.toLowerCase())){out.region ||= l;continue}
   if(COUNTY.test(l)){const cm=l.match(COUNTY);out.county ||= cm[0];const rest=l.replace(cm[0],'').replace(/[,\s]+$/,'').trim();if(rest)remaining.push(rest);continue}
   remaining.push(l);
  }
  if(!out.address1)out.address1=remaining.shift()||'';
  // In typical eBay UK multiline format: address1, optional address2, city, county, postcode.
  if(!out.address2&&remaining.length>=2)out.address2=remaining.shift()||'';
  if(!out.city&&remaining.length)out.city=remaining.shift()||'';
  if(!out.county&&remaining.length)out.county=remaining.shift()||'';
  if(!out.region&&/^(?:england|scotland|wales|northern ireland)$/i.test(out.country)){out.region=out.country;out.country='United Kingdom'}
  if(!out.region&&out.country.toLowerCase()==='united kingdom')out.region=/\b(?:BT\d|County (?:Londonderry|Antrim|Armagh|Down|Fermanagh|Tyrone))\b/i.test(out.postcode+' '+out.county)?'Northern Ireland':'England';
  if(out.phone){out.phone=out.phone.replace(/[^\d+]/g,'');if(out.phone.startsWith('0044'))out.phone='+'+out.phone.slice(2)}
  return out;
 }
 return {parse};
})();
