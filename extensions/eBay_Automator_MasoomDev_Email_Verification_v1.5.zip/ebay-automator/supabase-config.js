// Public Supabase configuration only. Never place secret/service_role keys here.
globalThis.MASOOMDEV_SUPABASE = {
  url: "https://uuvqawlqcnrcdribwava.supabase.co",
  anonKey: "sb_publishable_cXKjv4juWoZbJhV0ZUrIrQ_DwzhuENS"
};
