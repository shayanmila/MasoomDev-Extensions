// eBay Seller Automator - page helpers.
// Injected into the eBay Seller Hub tab by the side panel. Everything here mirrors the
// real Seller Hub screens (Active listings table, Edit quantity popup, End listing popup,
// Promoted listings popup, Relist form).
(() => {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const visible = (el) => !!el && el.getBoundingClientRect().width > 0 && getComputedStyle(el).visibility !== 'hidden';

  async function waitFor(fn, timeout = 8000, step = 150) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      const v = fn();
      if (v) return v;
      await sleep(step);
    }
    return null;
  }

  // Full click sequence (some eBay buttons ignore a bare .click())
  function realClick(el) {
    const opts = { bubbles: true, cancelable: true, view: window };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach((t) =>
      el.dispatchEvent(new MouseEvent(t, opts))
    );
    el.click();
  }

  function setValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    input.focus();
    setter.call(input, String(value));
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  const openDialogs = () =>
    [...document.querySelectorAll('.lightbox-dialog')].filter(
      (d) => getComputedStyle(d).display !== 'none' && d.getBoundingClientRect().width > 0
    );
  const dialogWith = (re) => openDialogs().find((d) => re.test(d.innerText));
  const buttonByText = (root, txt) =>
    [...root.querySelectorAll('button')].find((b) => b.innerText.trim() === txt && visible(b));

  async function closeDialog(d) {
    if (!d) return;
    const b = buttonByText(d, 'Cancel') || buttonByText(d, 'Close') || d.querySelector('button[aria-label*="Close"]');
    if (b) realClick(b);
    await sleep(500);
  }

  // Any visible popup (eBay uses both .lightbox-dialog and role=dialog)
  const anyDialog = (re) =>
    [...document.querySelectorAll('.lightbox-dialog, [role=dialog]')].find(
      (d) => getComputedStyle(d).display !== 'none' && d.getBoundingClientRect().width > 0 && re.test(d.innerText)
    );
  const campLink = (id) =>
    [...document.querySelectorAll('a[href*="/sh/ads/dashboard/campaign/"]')].find((a) => {
      const m = (a.getAttribute('href') || '').match(/\/campaign\/(\d+)(?:[/?#]|$)/);
      return m && m[1] === String(id);
    }) || null;
  const campStatus = (row) => {
    if (!row) return '';
    const m = row.innerText.match(/\b(Active|Paused|Ended|Scheduled|Pending|Out of budget|Running|Completed)\b/i);
    return m ? m[1] : 'Unknown';
  };

  const findRow = (id) => {
    const r = document.querySelector('tr[data-id="' + id + '"]');
    return r && r.querySelector('input[type=checkbox]') ? r : null;
  };

  async function getRow(id) {
    let r = findRow(id);
    if (r) return r;
    // Not in the current table: use the page search box (title / SKU / item number)
    const inp = document.querySelector('input[aria-label^="Search by title"]');
    if (!inp) return null;
    setValue(inp, id);
    ['keydown', 'keypress', 'keyup'].forEach((t) =>
      inp.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }))
    );
    return await waitFor(() => findRow(id), 10000, 250);
  }

  const isVariation = (r) => {
    const t = r.querySelector('td[class*=column__title]');
    return !!t && /\[\d+ variations?\]/i.test(t.innerText);
  };

  const num = (s) => {
    const m = String(s || '').replace(/,/g, '').match(/-?\d+(\.\d+)?/);
    return m ? Number(m[0]) : null;
  };
  const cellText = (r, col) => {
    const td = r.querySelector('td[class*="' + col + '"]');
    return td ? td.innerText.trim() : '';
  };

  const readRow = (r) => {
    const title = (r.querySelector('td[class*=column__title] a') || {}).innerText || '';
    const qty = (r.querySelector('td[class*=availableQuantity]') || {}).innerText || '';
    const promo = (r.querySelector('td[class*=promoteListing]') || {}).innerText || '';
    const m = promo.match(/Your ad rate:\s*([\d.]+)%/i);
    const sg = promo.match(/Suggested ad rate:\s*([\d.]+)%/i);
    const priceTxt = cellText(r, 'column__price');
    const pm = priceTxt.match(/[£$€]\s?([\d,]+(?:\.\d+)?)/);
    return {
      id: r.dataset.id,
      title: title.trim().slice(0, 120),
      sku: cellText(r, 'column__listingSKU').split('\n')[0],
      qty: qty.trim(),
      qtyNum: num(qty),
      price: pm && !/\sto\s/i.test(priceTxt) ? Number(pm[1].replace(/,/g, '')) : null,
      priceText: priceTxt.split('\n')[0],
      views: num(cellText(r, 'column__visitCount').split('\n')[0]),
      sold: num(cellText(r, 'column__soldQuantity')),
      watchers: num(cellText(r, 'column__watchCount')),
      adRate: m ? m[1] : null,
      suggested: sg ? sg[1] : null,
      promoted: /Promoted/i.test(promo) && !!m,
      variations: isVariation(r),
    };
  };

  // Generic "pencil -> popup -> Submit" editor used by price and variation edits
  async function editInline(r, col, label, dlgRe, value) {
    const td = r.querySelector('td[class*="' + col + '"]');
    const btn = td && td.querySelector('button[aria-label="' + label + '"]');
    if (!btn) return { ok: false, msg: 'Edit button not found (' + label + ')' };
    r.scrollIntoView({ block: 'center' });
    realClick(btn);
    const dlg = await waitFor(() => dialogWith(dlgRe), 6000);
    if (!dlg) return { ok: false, msg: 'Edit popup did not open' };
    const inp = dlg.querySelector('input[type=text], input:not([type])');
    if (!inp) { await closeDialog(dlg); return { ok: false, msg: 'Edit box not found' }; }
    setValue(inp, value);
    await sleep(400);
    const sub = buttonByText(dlg, 'Submit');
    if (!sub || sub.disabled) { await closeDialog(dlg); return { ok: false, msg: 'Submit button unavailable' }; }
    realClick(sub);
    const closed = await waitFor(() => !dialogWith(dlgRe), 10000);
    if (!closed) {
      const t = (dialogWith(dlgRe) || { innerText: '' }).innerText.replace(/\s+/g, ' ').slice(0, 160);
      await closeDialog(dialogWith(dlgRe));
      return { ok: false, msg: 'Popup stayed open: ' + t };
    }
    return { ok: true };
  }
  const money = (n) => '£' + Number(n).toFixed(2);

  const api = {
    ping: () => ({ ok: true, path: location.pathname }),

    // Read-only: what is on the page right now (used for the Preview step)
    async inspect(ids) {
      const out = {};
      for (const id of ids) {
        const r = findRow(id);
        out[id] = r ? Object.assign({ found: true }, readRow(r)) : { found: false };
      }
      return out;
    },

    async quantity(id, qty) {
      const r = await getRow(id);
      if (!r) return { ok: false, msg: 'Item not found in Active listings' };
      if (isVariation(r)) return { ok: false, msg: 'Variation listing - quantity is per variation (skipped)' };
      const td = r.querySelector('td[class*=availableQuantity]');
      const before = td.innerText.trim();
      if (before === String(qty)) return { ok: true, msg: 'Already ' + before + ' (no change)' };
      const btn = td.querySelector('button[aria-label="Edit Available quantity"]') || td.querySelector('button');
      if (!btn) return { ok: false, msg: 'No quantity edit button on this row' };
      r.scrollIntoView({ block: 'center' });
      realClick(btn);
      const dlg = await waitFor(() => dialogWith(/Edit quantity/), 6000);
      if (!dlg) return { ok: false, msg: 'Edit quantity popup did not open' };
      const inp = dlg.querySelector('input');
      if (!inp) return { ok: false, msg: 'Quantity box not found' };
      setValue(inp, qty);
      await sleep(400);
      const sub = buttonByText(dlg, 'Submit');
      if (!sub || sub.disabled) {
        await closeDialog(dlg);
        return { ok: false, msg: 'Submit button unavailable' };
      }
      realClick(sub);
      const closed = await waitFor(() => !dialogWith(/Edit quantity/), 10000);
      if (!closed) {
        const text = (dialogWith(/Edit quantity/) || { innerText: '' }).innerText.replace(/\s+/g, ' ').slice(0, 160);
        await closeDialog(dialogWith(/Edit quantity/));
        return { ok: false, msg: 'Popup stayed open: ' + text };
      }
      await sleep(1500);
      const r2 = findRow(id);
      const after = r2 ? r2.querySelector('td[class*=availableQuantity]').innerText.trim() : '?';
      return after === String(qty)
        ? { ok: true, msg: before + ' -> ' + after, before }
        : { ok: false, msg: 'Saved, but page shows ' + after + ' (expected ' + qty + ')' };
    },

    async end(id) {
      const r = await getRow(id);
      if (!r) return { ok: false, msg: 'Item not found in Active listings' };
      r.scrollIntoView({ block: 'center' });
      const more = r.querySelector('button[aria-label^="Show other actions"]');
      if (!more) return { ok: false, msg: 'Row actions menu not found' };
      realClick(more);
      const item = await waitFor(
        () => [...document.querySelectorAll('button.fake-menu__item')].find((b) => b.innerText.trim() === 'End listing' && visible(b)),
        5000
      );
      if (!item) return { ok: false, msg: '"End listing" not in the row menu' };
      realClick(item);
      const dlg = await waitFor(() => dialogWith(/Are you sure you want to end/), 6000);
      if (!dlg) return { ok: false, msg: 'End confirmation popup did not open' };
      const confirmBtn = [...dlg.querySelectorAll('button')].find((b) => b.innerText.trim() === 'End listing' && visible(b));
      if (!confirmBtn) return { ok: false, msg: 'Confirm button not found' };
      realClick(confirmBtn);
      const closed = await waitFor(() => !dialogWith(/Are you sure you want to end/), 10000);
      if (!closed) {
        await closeDialog(dialogWith(/Are you sure you want to end/));
        return { ok: false, msg: 'End popup stayed open' };
      }
      const gone = await waitFor(() => !findRow(id), 8000, 300);
      return gone ? { ok: true, msg: 'Ended' } : { ok: true, msg: 'Ended (row still showing - refresh to confirm)' };
    },

    // value: a number like "12.5" for a fixed ad rate, or "dynamic"
    async adrate(id, value) {
      const r = await getRow(id);
      if (!r) return { ok: false, msg: 'Item not found in Active listings' };
      const before = readRow(r).adRate;
      const wantDynamic = String(value).toLowerCase() === 'dynamic';
      if (!wantDynamic && before !== null && Number(before) === Number(value)) {
        return { ok: true, msg: 'Already ' + before + '% (no change)' };
      }
      const btn = r.querySelector('td[class*=promoteListing] button');
      if (!btn) return { ok: false, msg: 'No promoted-listing button on this row' };
      r.scrollIntoView({ block: 'center' });
      realClick(btn);
      const dlg = await waitFor(() => dialogWith(/Promoted listings/) && dialogWith(/Promoted listings/).querySelector('input[type=radio]'), 8000);
      const d = dialogWith(/Promoted listings/);
      if (!dlg || !d) return { ok: false, msg: 'Promoted listings popup did not open' };
      const radios = [...d.querySelectorAll('input[type=radio]')];
      const fixed = radios.find((x) => /FIXED/.test(x.value));
      const dyn = radios.find((x) => /DYNAMIC/.test(x.value));
      if (wantDynamic) {
        if (!dyn) { await closeDialog(d); return { ok: false, msg: 'Dynamic option not found' }; }
        realClick(dyn);
      } else {
        if (!fixed) { await closeDialog(d); return { ok: false, msg: 'Fixed-rate option not found (is the listing promoted?)' }; }
        if (!fixed.checked) realClick(fixed);
        await sleep(700);
        const rateInput = await waitFor(
          () => [...d.querySelectorAll('input[type=text]')].find((i) => i.name !== 'PLScampaignDropdown' && /^\d+(\.\d+)?$/.test(i.value) && visible(i)),
          4000
        );
        if (!rateInput) { await closeDialog(d); return { ok: false, msg: 'Ad rate box not found' }; }
        setValue(rateInput, value);
      }
      await sleep(600);
      const apply = buttonByText(d, 'Apply');
      if (!apply || apply.disabled) {
        await closeDialog(d);
        return { ok: false, msg: 'Apply is disabled (rate may be invalid or below the allowed minimum)' };
      }
      realClick(apply);
      const closed = await waitFor(() => !dialogWith(/Promoted listings/), 12000);
      if (!closed) {
        const t = (dialogWith(/Promoted listings/) || { innerText: '' }).innerText.replace(/\s+/g, ' ').slice(0, 160);
        await closeDialog(dialogWith(/Promoted listings/));
        return { ok: false, msg: 'Popup stayed open: ' + t };
      }
      await sleep(2000);
      const r2 = findRow(id);
      const after = r2 ? readRow(r2).adRate : null;
      if (wantDynamic) return { ok: true, msg: 'Set to dynamic rate' };
      return after !== null && Number(after) === Number(value)
        ? { ok: true, msg: (before || '?') + '% -> ' + after + '%', before }
        : { ok: false, msg: 'Applied, but page shows ' + after + '% (expected ' + value + '%)' };
    },

    // spec: "9.99", "+10%", "-5%", "+0.50", "-1"
    async price(id, spec) {
      const r = await getRow(id);
      if (!r) return { ok: false, msg: 'Item not found in Active listings' };
      if (isVariation(r)) return { ok: false, msg: 'Variation listing - use the Variation price mode' };
      const d = readRow(r);
      if (d.price == null) return { ok: false, msg: 'Could not read the current price' };
      const np = window.Logic.calcPrice(d.price, spec);
      if (np == null) return { ok: false, msg: 'Invalid new price from "' + spec + '"' };
      if (Math.abs(np - d.price) < 0.005) return { ok: true, msg: 'Already ' + money(d.price) + ' (no change)', before: d.price.toFixed(2) };
      const res = await editInline(r, 'column__price', 'Edit Current price', /Edit price/, np.toFixed(2));
      if (!res.ok) return res;
      await sleep(1500);
      const r2 = findRow(id);
      const after = r2 ? readRow(r2).price : null;
      return after !== null && Math.abs(after - np) < 0.005
        ? { ok: true, msg: money(d.price) + ' -> ' + money(np), before: d.price.toFixed(2) }
        : { ok: false, msg: 'Saved, but page shows ' + (after === null ? 'a different price format' : money(after)) + ' (expected ' + money(np) + ')' };
    },

    // Sets the fixed ad rate to the "Suggested ad rate" eBay shows on the row
    async adsuggest(id) {
      const r = await getRow(id);
      if (!r) return { ok: false, msg: 'Item not found in Active listings' };
      const d = readRow(r);
      if (d.suggested == null) return { ok: false, msg: 'No suggested ad rate shown (listing may not be promoted)' };
      const rate = Number(d.suggested);
      if (!(rate >= 2 && rate <= 100)) return { ok: false, msg: 'Suggested rate out of range: ' + d.suggested };
      return await api.adrate(id, String(rate));
    },

    // Runs on /sh/lst/active/<parentItemId> (the variations table).
    // field: 'qty' | 'price'; match: text to find in the variation name or SKU ('' = all); spec: value
    async varEdit(field, match, spec) {
      await waitFor(() => document.querySelector('tbody tr[data-id] td[class*="column__availableQuantity"]'), 20000);
      const rows = [...document.querySelectorAll('tbody tr[data-id]')].filter((r) => r.querySelector('td[class*="column__availableQuantity"]'));
      if (!rows.length) return { ok: false, msg: 'No variation rows found (is this a variation listing?)' };
      const m = String(match || '').toLowerCase();
      const targets = rows.filter((r) => !m || (cellText(r, 'column__variationTitle') + ' ' + cellText(r, 'column__listingSKU')).toLowerCase().includes(m));
      if (!targets.length) return { ok: false, msg: 'No variation matched "' + match + '"' };
      const ids = targets.map((r) => r.dataset.id);
      const notes = []; let bad = 0;
      for (const vid of ids) {
        const r = document.querySelector('tr[data-id="' + vid + '"]');
        if (!r) { bad++; notes.push(vid + ': row disappeared'); continue; }
        const label = cellText(r, 'column__variationTitle').split('\n')[0].replace(/^.*::\s*/, '').slice(0, 28) || vid;
        if (field === 'qty') {
          const before = cellText(r, 'column__availableQuantity');
          if (before === String(spec)) { notes.push(label + ': already ' + before); continue; }
          const res = await editInline(r, 'column__availableQuantity', 'Edit Available quantity', /Edit quantity/, spec);
          if (!res.ok) { bad++; notes.push(label + ': ' + res.msg); continue; }
          await sleep(1400);
          const r2 = document.querySelector('tr[data-id="' + vid + '"]');
          const after = r2 ? cellText(r2, 'column__availableQuantity') : '?';
          if (after === String(spec)) notes.push(label + ': ' + before + '->' + after);
          else { bad++; notes.push(label + ': page shows ' + after); }
        } else {
          const pm = cellText(r, 'column__price').match(/[£$€]\s?([\d,]+(?:\.\d+)?)/);
          const cur = pm ? Number(pm[1].replace(/,/g, '')) : null;
          const np = window.Logic.calcPrice(cur, spec);
          if (np == null) { bad++; notes.push(label + ': cannot calculate price'); continue; }
          if (Math.abs(np - cur) < 0.005) { notes.push(label + ': already ' + money(cur)); continue; }
          const res = await editInline(r, 'column__price', 'Edit Current price', /Edit price/, np.toFixed(2));
          if (!res.ok) { bad++; notes.push(label + ': ' + res.msg); continue; }
          await sleep(1400);
          const r2 = document.querySelector('tr[data-id="' + vid + '"]');
          const pm2 = r2 ? cellText(r2, 'column__price').match(/[£$€]\s?([\d,]+(?:\.\d+)?)/) : null;
          const after = pm2 ? Number(pm2[1].replace(/,/g, '')) : null;
          if (after !== null && Math.abs(after - np) < 0.005) notes.push(label + ': ' + money(cur) + '->' + money(np));
          else { bad++; notes.push(label + ': page shows ' + (after === null ? '?' : money(after))); }
        }
        await sleep(700);
      }
      const summary = (ids.length - bad) + '/' + ids.length + ' variations ok. ' + notes.join('; ');
      return { ok: bad === 0, msg: summary.slice(0, 400) };
    },

    // ---- read-only scans used by "Find by rule" and Export ----
    scan() {
      const rows = [...document.querySelectorAll('tbody tr[data-id]')].filter((r) => r.querySelector('input[type=checkbox]'));
      const m = document.body.innerText.match(/Manage active listings\s*\((\d+)\)/i);
      return { total: m ? Number(m[1]) : null, rows: rows.map(readRow) };
    },
    scanEnded() {
      const rows = [...document.querySelectorAll('tbody tr[data-id]')].filter((r) => r.querySelector('input[type=checkbox]'));
      return {
        rows: rows.map((r) => ({
          id: r.dataset.id,
          title: ((r.querySelector('td[class*=column__title] a') || {}).innerText || '').trim(),
          sku: cellText(r, 'column__listingSKU').split('\n')[0],
          format: cellText(r, 'column__format').split('\n')[0],
          price: cellText(r, 'column__price').split('\n')[0],
          qty: cellText(r, 'column__availableQuantity'),
          views: cellText(r, 'column__visitCount').split('\n')[0],
          watchers: cellText(r, 'column__watchCount'),
          endDate: cellText(r, 'column__actualEndDate').replace(/\s+/g, ' '),
          soldStatus: cellText(r, 'column__soldStatus').replace(/\s+/g, ' '),
          relistStatus: cellText(r, 'column__relistStatus').replace(/\s+/g, ' '),
        })),
      };
    },
    // Orders: order number, item id(s), quantity, money and dates. Buyer names/addresses are NOT read.
    scanOrders() {
      const orders = [...document.querySelectorAll('tr.order-info')];
      const rows = orders.map((o) => {
        const cells = [...o.children];
        const orderNo = ((cells[2] ? cells[2].innerText : '').match(/\d{2}-\d{5}-\d{5}/) || [''])[0];
        const itemIds = new Set();
        let s = o.nextElementSibling;
        while (s && !s.classList.contains('order-info') && !s.classList.contains('buyer-note-row')) {
          (s.className.match(/itemid_(\d+)/g) || []).forEach((c) => itemIds.add(c.replace('itemid_', '')));
          s = s.nextElementSibling;
        }
        const first = (c) => (c ? c.innerText.split('\n')[0].trim() : '');
        const disp = (cells[1] ? cells[1].innerText : '').match(/Dispatch by ([^\n]+)/);
        return {
          orderNo,
          itemIds: [...itemIds].join(' '),
          quantity: first(cells[3]),
          subtotal: first(cells[4]),
          total: first(cells[5]),
          dateSold: cells[6] ? cells[6].innerText.replace(/\s+/g, ' ').trim() : '',
          datePaid: cells[7] ? cells[7].innerText.replace(/\s+/g, ' ').trim() : '',
          dispatchBy: disp ? disp[1].trim() : '',
        };
      });
      return { rows: rows.filter((x) => x.orderNo) };
    },

    // ================= Promoted Listings CAMPAIGNS =================
    // Runs on /sh/ads/dashboard/campaigns
    scanCampaigns() {
      const links = [...document.querySelectorAll('a[href*="/sh/ads/dashboard/campaign/"]')];
      const seen = new Set();
      const rows = [];
      for (const a of links) {
        const m = (a.getAttribute('href') || '').match(/\/campaign\/(\d+)/);
        if (!m || seen.has(m[1])) continue;
        seen.add(m[1]);
        const row = a.closest('.pl-grid__rows--group') || a.parentElement;
        rows.push({
          id: m[1],
          name: a.innerText.trim(),
          status: campStatus(row),
          type: /Priority/i.test(row.innerText) ? 'Priority' : /General/i.test(row.innerText) ? 'General' : '',
          text: row.innerText.replace(/\s+/g, ' ').trim().slice(0, 140),
        });
      }
      return { rows };
    },

    // action: 'End' | 'Pause'. Uses the row's "More actions" menu.
    async campAction(id, action) {
      await waitFor(() => campLink(id), 25000, 300);
      const a = campLink(id);
      if (!a) return { ok: false, msg: 'Campaign not found on the campaigns page' };
      const getRow = () => { const x = campLink(id); return x ? (x.closest('.pl-grid__rows--group') || x.parentElement) : null; };
      const row = getRow();
      const s0 = campStatus(row);
      if (action === 'End' && /ended/i.test(s0)) return { ok: true, msg: 'Already ended' };
      if (action === 'Pause' && /paused/i.test(s0)) return { ok: true, msg: 'Already paused' };
      const mb = [...row.querySelectorAll('button')].find((b) => /menu-button__button/.test(b.className));
      if (!mb) return { ok: false, msg: 'Row actions menu not found' };
      row.scrollIntoView({ block: 'center' });
      realClick(mb);
      const item = await waitFor(
        () => [...document.querySelectorAll('div,span,button,a,li')].find((e) => e.children.length === 0 && e.textContent.trim() === action && visible(e)),
        5000
      );
      if (!item) return { ok: false, msg: '"' + action + '" not found in the campaign menu (status: ' + s0 + ')' };
      realClick(item);
      // Possible confirmation popup (generic handling)
      const dlg = await waitFor(() => anyDialog(new RegExp(action + '|campaign|sure|confirm', 'i')), 4000);
      if (dlg) {
        const okBtn = [...dlg.querySelectorAll('button')].find((b) => visible(b) && /^(end|end campaign|pause|pause campaign|confirm|yes|yes, end|yes, pause|ok|continue)$/i.test(b.innerText.trim()));
        if (!okBtn) {
          const t = dlg.innerText.replace(/\s+/g, ' ').slice(0, 160);
          await closeDialog(dlg);
          return { ok: false, msg: 'Unexpected popup (not confirmed): ' + t };
        }
        realClick(okBtn);
      }
      // Wait for the status to change (or the row to leave the list)
      const t0 = Date.now();
      while (Date.now() - t0 < 15000) {
        await sleep(1000);
        const r2 = getRow();
        if (!r2) return { ok: true, msg: action === 'End' ? 'Ended (no longer listed)' : 'Paused (no longer listed)' };
        const s = campStatus(r2);
        if (action === 'End' && /ended/i.test(s)) return { ok: true, msg: s0 + ' -> ' + s };
        if (action === 'Pause' && /paused/i.test(s)) return { ok: true, msg: s0 + ' -> ' + s };
      }
      return { ok: false, msg: 'Clicked "' + action + '" but status is still "' + campStatus(getRow()) + '" - check the campaigns page' };
    },

    // Runs on /sh/ads/campaign. opts: {ids:[], name, rateMode:'dynamic'|'fixed', rate, launch:boolean}
    async campCreate(opts) {
      const tg = (re) => [...document.querySelectorAll('button.toggle-button')].find((b) => re.test(b.innerText.trim()));
      const press = (b) => { if (b.getAttribute('aria-pressed') !== 'true') realClick(b); };
      const b1 = await waitFor(() => tg(/Promote your listings/i), 30000, 400);
      if (!b1) return { ok: false, msg: 'Create-campaign page did not load' };
      press(b1);
      const gen = await waitFor(() => tg(/^General/), 10000);
      if (!gen) return { ok: false, msg: '"General" strategy option not found' };
      press(gen);
      const addBtn = await waitFor(() => [...document.querySelectorAll('button')].find((b) => b.innerText.trim() === 'Add listings' && visible(b)), 10000);
      if (!addBtn) return { ok: false, msg: '"Add listings" button not found' };
      realClick(addBtn);
      const dlg = await waitFor(() => anyDialog(/Add listings to your campaign/), 12000);
      if (!dlg) return { ok: false, msg: 'Add listings popup did not open' };
      const tab = await waitFor(() => [...dlg.querySelectorAll('[role=tab]')].find((t) => t.innerText.trim() === 'Item IDs'), 8000);
      if (!tab) return { ok: false, msg: '"Item IDs" tab not found' };
      realClick(tab);
      const ta = await waitFor(() => dlg.querySelector('textarea'), 6000);
      if (!ta) return { ok: false, msg: 'Item ID box not found' };
      const taSet = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
      ta.focus();
      taSet.call(ta, opts.ids.join('\n'));
      ta.dispatchEvent(new Event('input', { bubbles: true }));
      ta.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(800);
      const confirmAdd = [...dlg.querySelectorAll('button')].find((b) => b.innerText.trim() === 'Add listings' && visible(b));
      if (!confirmAdd) return { ok: false, msg: 'Popup "Add listings" button missing' };
      realClick(confirmAdd);
      const closed = await waitFor(() => !anyDialog(/Add listings to your campaign/), 45000, 400);
      if (!closed) {
        const t = (anyDialog(/Add listings to your campaign/) || { innerText: '' }).innerText.replace(/\s+/g, ' ').slice(0, 200);
        return { ok: false, msg: 'Add listings popup did not close: ' + t };
      }
      await sleep(2000);
      const cm = document.body.innerText.match(/(\d[\d,]*)\s+listings?\s+in this campaign/i);
      const added = cm ? Number(cm[1].replace(/,/g, '')) : 0;
      if (!added) return { ok: false, msg: 'eBay added 0 listings (they may already be in another campaign or not eligible)' };

      if (opts.rateMode === 'fixed') {
        const t = await waitFor(() => tg(/^Fixed ad rate/), 6000);
        if (!t) return { ok: false, msg: 'Fixed ad rate option not found' };
        press(t);
        const inp = await waitFor(() => document.querySelector('input[name="singleAdrate"]'), 8000);
        if (!inp) return { ok: false, msg: 'Fixed ad rate box not found' };
        setValue(inp, opts.rate);
        inp.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
        inp.blur();
      } else {
        const t = await waitFor(() => tg(/^Dynamic ad rate/), 6000);
        if (!t) return { ok: false, msg: 'Dynamic ad rate option not found' };
        press(t);
      }
      const nameInp = await waitFor(() => document.querySelector('input[placeholder="Enter a campaign name"]'), 6000);
      if (!nameInp) return { ok: false, msg: 'Campaign name box not found' };
      setValue(nameInp, opts.name);
      nameInp.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
      nameInp.blur();
      await sleep(1000);
      const launchBtn = await waitFor(() => { const b = document.querySelector('#page-unified-next'); return b && !b.disabled ? b : null; }, 12000);
      if (!launchBtn) {
        const err = [...document.querySelectorAll('[role=alert],[class*=error]')].filter(visible).map((e) => e.innerText.replace(/\s+/g, ' ').trim()).filter(Boolean).slice(0, 2).join(' | ');
        return { ok: false, msg: 'Launch button stayed disabled' + (err ? ': ' + err : ' (a required field may be missing)') + '. ' + added + ' listings were added to the form.' };
      }
      return { ok: true, added, ready: true, msg: added + ' of ' + opts.ids.length + ' listings added. Form is ready.' };
    },
    campLaunch() {
      const b = document.querySelector('#page-unified-next');
      if (!b || b.disabled) return { ok: false, msg: 'Launch button not available' };
      realClick(b);
      return { ok: true, clicked: true };
    },
    // Called repeatedly after Launch: confirms a possible popup, reports errors
    async campPoll() {
      const dlg = anyDialog(/launch|campaign|sure|confirm/i);
      if (dlg) {
        const okBtn = [...dlg.querySelectorAll('button')].find((b) => visible(b) && /^(launch|launch campaign|confirm|yes|ok|continue)$/i.test(b.innerText.trim()));
        if (okBtn) { realClick(okBtn); return { state: 'confirmed' }; }
        return { state: 'popup', msg: dlg.innerText.replace(/\s+/g, ' ').slice(0, 200) };
      }
      const err = [...document.querySelectorAll('[role=alert],[class*=error]')].filter(visible).map((e) => e.innerText.replace(/\s+/g, ' ').trim()).filter(Boolean)[0];
      return err ? { state: 'error', msg: err.slice(0, 200) } : { state: 'waiting' };
    },

    // Runs on /sl/list?mode=RelistItem&itemId=... (the relist form)
    async relistPrepare() {
      const btn = await waitFor(() => document.querySelector('button[_track$="listItCallToAction"]'), 30000, 400);
      if (!btn) return { ok: false, msg: 'Relist form did not finish loading (no "List" button)' };
      return { ok: true, label: btn.innerText.trim() };
    },
    async relistSubmit() {
      const btn = document.querySelector('button[_track$="listItCallToAction"]');
      if (!btn) return { ok: false, msg: 'List button missing' };
      if (btn.disabled) return { ok: false, msg: 'List button disabled - the form needs attention' };
      btn.scrollIntoView({ block: 'center' });
      realClick(btn);
      return { ok: true, clicked: true };
    },
    relistErrors() {
      const el = document.querySelector('[role=alert], .inline-notice--attention, .inline-notice--error');
      return el ? el.innerText.replace(/\s+/g, ' ').trim().slice(0, 200) : '';
    },
  };

  window.__ebz = api;
})();
