
// Supabase Auth REST API. Only publishable/anon keys belong in this client.
const cfg = globalThis.MASOOMDEV_SUPABASE;
const base = cfg.url.replace(/\/+$/, '') + '/auth/v1';
function configured() { return /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(cfg.url) && !cfg.url.includes('YOUR_') && cfg.anonKey && !cfg.anonKey.includes('YOUR_'); }
async function request(path, method='GET', body, token) {
  if (!configured()) throw new Error('Supabase is not configured. See SETUP.md.');
  const res = await fetch(base+path,{method,headers:{'apikey':cfg.anonKey,'Content-Type':'application/json',...(token?{'Authorization':'Bearer '+token}:{})},...(body?{body:JSON.stringify(body)}:{})});
  const data = await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.msg || data.error_description || data.message || data.error || 'Authentication failed');
  return data;
}
const getSession = async () => (await chrome.storage.local.get('masoomdevSession')).masoomdevSession;
async function saveSession(data) {
  if(!data.access_token || !data.refresh_token) throw new Error('No session returned.');
  await chrome.storage.local.set({masoomdevSession:{access_token:data.access_token,refresh_token:data.refresh_token,expires_at:Date.now()+(data.expires_in||3600)*1000,email:data.user?.email||''}});
}
async function validSession() {
  const s=await getSession();
  if(!s) return false;
  try {
    let token=s.access_token;
    if(Date.now()>s.expires_at-60000) {
      const refreshed=await request('/token?grant_type=refresh_token','POST',{refresh_token:s.refresh_token});
      await saveSession(refreshed); token=refreshed.access_token;
    }
    const user=await request('/user','GET',null,token);
    return !!user.id;
  } catch { await chrome.storage.local.remove('masoomdevSession'); return false; }
}
async function signOut() {
  const s=await getSession();
  if(s) await request('/logout','POST',null,s.access_token).catch(()=>{});
  await chrome.storage.local.remove('masoomdevSession');
}
globalThis.MasoomAuth={request,saveSession,validSession,signOut,configured};
