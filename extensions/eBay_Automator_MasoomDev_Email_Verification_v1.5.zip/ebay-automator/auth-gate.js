
// Gate the existing automation scripts until an authenticated session is verified.
(async()=>{
 const load=path=>new Promise((resolve,reject)=>{
  const s=document.createElement('script');s.src=path;s.onload=resolve;s.onerror=reject;document.body.appendChild(s);
 });
 try{
  await load('supabase-config.js');await load('auth-client.js');
  if(!await MasoomAuth.validSession()){location.replace('auth.html');return;}
  document.getElementById('signOut').onclick=async()=>{await MasoomAuth.signOut();location.replace('auth.html')};
  await load('logic.js');await load('sidepanel.js');
 }catch(e){document.body.textContent='Activation error: '+e.message;}
})();
