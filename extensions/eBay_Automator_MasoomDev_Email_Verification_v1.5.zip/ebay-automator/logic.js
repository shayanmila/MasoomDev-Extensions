// Pure logic (no browser APIs) so it can be unit-tested with Node.
(function (root) {
  const ID_RE = /^\d{9,14}$/;
  const VAR_MODES = ['varqty', 'varprice'];

  // "9.99" (absolute), "+10%" / "-5%" (percent change), "+0.50" / "-1" (amount change)
  function parsePriceSpec(s) {
    s = String(s == null ? '' : s).trim().replace(/[£$€\s]/g, '');
    let m;
    if ((m = s.match(/^([+-])(\d+(?:\.\d+)?)%$/))) return { type: 'pct', n: (m[1] === '-' ? -1 : 1) * Number(m[2]) };
    if ((m = s.match(/^([+-])(\d+(?:\.\d+)?)$/))) return { type: 'amt', n: (m[1] === '-' ? -1 : 1) * Number(m[2]) };
    if ((m = s.match(/^(\d+(?:\.\d+)?)$/))) return Number(m[1]) >= 0.01 ? { type: 'abs', n: Number(m[1]) } : null;
    return null;
  }

  function calcPrice(cur, spec) {
    const p = parsePriceSpec(spec);
    if (!p || cur == null || isNaN(cur)) return null;
    let v;
    if (p.type === 'abs') v = p.n;
    else if (p.type === 'pct') v = cur * (1 + p.n / 100);
    else v = cur + p.n;
    v = Math.round(v * 100) / 100;
    return v >= 0.01 ? v : null;
  }

  function normaliseRate(v) {
    v = String(v == null ? '' : v).trim().replace('%', '');
    if (v.toLowerCase() === 'dynamic') return 'dynamic';
    if (/^\d+(\.\d+)?$/.test(v) && Number(v) >= 2 && Number(v) <= 100) return String(Number(v));
    return null;
  }

  // Returns { items:[{id,value,text,status,msg,now}], problems:[] }
  function parseInput(text, mode) {
    const items = [], problems = [], seen = new Set();
    let firstContent = true;
    String(text || '').split(/\r?\n/).forEach((raw, i) => {
      const line = raw.trim();
      if (!line) return;
      const isFirst = firstContent; firstContent = false;
      const isVar = VAR_MODES.includes(mode);
      const parts = (isVar ? line.split(/[,\t;]/) : line.split(/[,\t;]+|\s+/)).map((s) => s.trim()).filter(Boolean);
      const id = (parts[0] || '').replace(/\D/g, '');
      if (!ID_RE.test(id) || /[A-Za-z]/.test(parts[0] || '')) {
        if (!isFirst) problems.push('Line ' + (i + 1) + ': "' + (parts[0] || '') + '" is not an Item ID');
        return; // first bad line = CSV header, silently skipped
      }
      let value = '', vtext = '';
      const needs = { quantity: 1, varqty: 1, price: 1, varprice: 1, adrate: 1 }[mode];
      if (needs) {
        if (isVar) {
          if (parts.length < 2) { problems.push('Line ' + (i + 1) + ': needs "ItemID, value" or "ItemID, variation text, value"'); return; }
          value = parts[parts.length - 1];
          vtext = parts.slice(1, -1).join(', ');
        } else {
          value = parts[1] || '';
        }
        if (mode === 'quantity' || mode === 'varqty') {
          if (!/^\d+$/.test(value) || Number(value) > 99999) { problems.push('Line ' + (i + 1) + ': quantity must be a whole number (0-99999)'); return; }
        } else if (mode === 'price' || mode === 'varprice') {
          if (!parsePriceSpec(value)) { problems.push('Line ' + (i + 1) + ': price must be like 9.99, +10%, -5%, +0.50 or -1'); return; }
          value = value.replace(/[£$€\s]/g, '');
        } else if (mode === 'adrate') {
          const r = normaliseRate(value);
          if (!r) { problems.push('Line ' + (i + 1) + ': ad rate must be 2-100 or "dynamic"'); return; }
          value = r;
        }
      }
      const key = id + '|' + vtext;
      if (seen.has(key)) { problems.push('Line ' + (i + 1) + ': duplicate ' + id + ' (ignored)'); return; }
      seen.add(key);
      items.push({ id, value, text: vtext, status: 'pending', msg: '', now: '', title: '' });
    });
    return { items, problems };
  }

  // Rule filter used by "Find items by rule". All provided conditions must pass.
  function matchesRule(row, f) {
    const num = (v) => (v === '' || v == null || isNaN(Number(v)) ? null : Number(v));
    const chk = (val, min, max) => {
      min = num(min); max = num(max);
      if (min === null && max === null) return true;
      if (val == null) return false;
      if (min !== null && val < min) return false;
      if (max !== null && val > max) return false;
      return true;
    };
    // "Always" conditions (must hold in both AND and OR mode)
    if (f.skipVar && row.variations) return false;
    if (f.promoted === 'yes' && !row.promoted) return false;
    if (f.promoted === 'no' && row.promoted) return false;
    // Rule conditions: combined with AND (default) or OR ("any")
    const has = (a, b) => num(a) !== null || num(b) !== null;
    const checks = [];
    if (f.titleHas) {
      const t = (row.title || '').toLowerCase();
      checks.push(String(f.titleHas).toLowerCase().split(/\s+/).filter(Boolean).every((w) => t.includes(w)));
    }
    if (has(f.qtyMin, f.qtyMax)) checks.push(chk(row.qtyNum, f.qtyMin, f.qtyMax));
    if (has(f.viewsMin, f.viewsMax)) checks.push(chk(row.views, f.viewsMin, f.viewsMax));
    if (has(f.soldMin, f.soldMax)) checks.push(chk(row.sold, f.soldMin, f.soldMax));
    if (has(f.priceMin, f.priceMax)) checks.push(chk(row.price, f.priceMin, f.priceMax));
    if (!checks.length) return true;
    return f.combine === 'any' ? checks.some(Boolean) : checks.every(Boolean);
  }

  function csvCell(v) {
    v = v == null ? '' : String(v);
    return /[",\r\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
  function toCsv(rows, cols) {
    const head = cols.map((c) => csvCell(c.label)).join(',');
    const body = rows.map((r) => cols.map((c) => csvCell(r[c.key])).join(','));
    return '﻿' + [head].concat(body).join('\r\n');
  }

  const api = { parsePriceSpec, calcPrice, normaliseRate, parseInput, matchesRule, toCsv, csvCell };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Logic = api;
})(typeof self !== 'undefined' ? self : this);
