// eBay Seller Automator v1.1 - side panel logic.
// Flow: choose action -> paste/upload (or "Find items by rule") -> Preview -> tick "reviewed" -> Confirm & Run.

const L = window.Logic;

const LIST = '/sh/lst/active';
const CAMPS = '/sh/ads/dashboard/campaigns';
const NEWCAMP = '/sh/ads/campaign';
const isCamp = (m) => m === 'campNew' || m === 'campEnd' || m === 'campPause';
const selfNav = (m) => m === 'relist' || m.startsWith('var') || isCamp(m); // modes that open their own pages
const MODES = {
  quantity: {
    label: 'Item ID, new quantity', kind: 'run', page: LIST, exact: true, rules: true, needsValue: true, skipVarDefault: true,
    valueHint: 'New quantity, e.g. 10',
    help: 'One per line: <code>ItemID, quantity</code>. Works on <b>Active listings</b>. Variation listings are skipped (use "Variation quantity").',
    placeholder: '287613445660, 12\n287533904914, 5',
  },
  price: {
    label: 'Item ID, price or change', kind: 'run', page: LIST, exact: true, rules: true, needsValue: true, skipVarDefault: true,
    valueHint: 'e.g. 9.99, +10%, -5%, +0.50, -1',
    help: 'One per line: <code>ItemID, 9.99</code> (exact) or <code>ItemID, +10%</code> / <code>-5%</code> / <code>+0.50</code> / <code>-1</code> (change). The preview shows the calculated new price. Works on <b>Active listings</b>; variation listings are skipped.',
    placeholder: '287613445660, 7.99\n287533904914, +10%\n287533904915, -0.50',
  },
  adrate: {
    label: 'Item ID, ad rate %', kind: 'run', page: LIST, exact: true, rules: true, needsValue: true, skipVarDefault: false,
    valueHint: 'Rate 2-100 or "dynamic"',
    help: 'One per line: <code>ItemID, 12.5</code> for a fixed Promoted Listings rate (2-100), or <code>ItemID, dynamic</code>.',
    placeholder: '287613445660, 12.5\n287533904914, dynamic',
  },
  adsuggest: {
    label: 'Item IDs (use eBay suggested ad rate)', kind: 'run', page: LIST, exact: true, rules: true, needsValue: false, skipVarDefault: false,
    help: 'One <b>Item ID</b> per line. Each listing\'s fixed ad rate is set to the "Suggested ad rate" shown on its row (the preview shows both).',
    placeholder: '287613445660\n287533904914',
  },
  varqty: {
    label: 'Parent Item ID, [variation text,] quantity', kind: 'run', page: LIST, exact: false, rules: false, needsValue: true,
    help: 'For listings with variations. <code>ParentID, 10</code> sets <b>every</b> variation to 10. <code>ParentID, 6 Pcs, 10</code> sets only variations whose name or SKU contains "6 Pcs". The tool opens each listing\'s variation page.',
    placeholder: '287533904914, 10\n287533904914, 6 Pcs Mixed, 7',
  },
  varprice: {
    label: 'Parent Item ID, [variation text,] price or change', kind: 'run', page: LIST, exact: false, rules: false, needsValue: true,
    help: 'Like Variation quantity but for prices: <code>ParentID, +5%</code> (all) or <code>ParentID, 6 Pcs, 5.99</code> (matching variations).',
    placeholder: '287533904914, +5%\n287533904914, 6 Pcs Mixed, 5.99',
  },
  campNew: {
    label: 'Item IDs for the new campaign (use "Find items by rule" below, or paste)', kind: 'run', page: LIST, exact: false, rules: true, needsValue: false, skipVarDefault: true,
    help: 'Builds a <b>General</b> Promoted Listings campaign. 1) Fill the list with "Find items by rule" (views, sold, price... or <b>ALL listings</b>) or paste Item IDs. 2) Set the name and ad rate below. 3) Preview, then Confirm. By default the tool fills eBay\'s form and <b>stops before Launch</b> so you can check it. Listings already in another campaign are not eligible; the tool reports how many eBay accepted.',
    placeholder: '287613445660\n287533904914',
  },
  campEnd: {
    label: 'Campaign IDs to END (click "Load my campaigns")', kind: 'run', page: CAMPS, exact: false, rules: false, needsValue: false,
    help: 'Ends Promoted Listings campaigns (from the campaign\'s menu). Click <b>Load my campaigns</b> to fill the list, or paste campaign IDs (the number in each campaign\'s link). Ending a campaign cannot be reversed; use Pause if you may want it back.',
    placeholder: '167368770015',
  },
  campPause: {
    label: 'Campaign IDs to PAUSE (click "Load my campaigns")', kind: 'run', page: CAMPS, exact: false, rules: false, needsValue: false,
    help: 'Pauses campaigns using the campaign menu. Click <b>Load my campaigns</b> to fill the list, or paste campaign IDs.',
    placeholder: '167368770015',
  },
  end: {
    label: 'Item IDs to END', kind: 'run', page: LIST, exact: true, rules: true, needsValue: false, skipVarDefault: false,
    help: 'One <b>Item ID</b> per line. Each listing is ended through the normal eBay confirmation. Ending cannot be undone (you would have to relist).',
    placeholder: '287613445660\n287533904914',
  },
  relist: {
    label: 'Item IDs to RELIST', kind: 'run', page: '/sh/lst/ended', exact: false, rules: false, needsValue: false,
    help: 'One <b>old Item ID</b> per line (from your Ended list). Opens each relist form and presses "List". Relisting can create new listings and fees, so review carefully.',
    placeholder: '287686795411',
  },
  exportActive: {
    label: '(not used)', kind: 'export', page: LIST, exact: true, rules: false, needsValue: false,
    help: 'Downloads a CSV of every row loaded on the <b>Active listings</b> page: item ID, title, SKU, price, quantity, views, sold, watchers, ad rate and suggested ad rate. Tip: set "Results per page" to the maximum so all listings are loaded.',
    placeholder: '',
  },
  exportEnded: {
    label: '(not used)', kind: 'export', page: '/sh/lst/ended', exact: true, rules: false, needsValue: false,
    help: 'Downloads a CSV of the rows loaded on the <b>Inactive / Ended</b> page.',
    placeholder: '',
  },
  exportOrders: {
    label: 'Optional: order numbers or item IDs to look up (blank = all rows on this page)', kind: 'export', page: '/sh/ord', exact: false, rules: false, needsValue: false,
    help: 'Open <b>Orders</b> (any filter). Downloads a CSV of the orders loaded on the page: order number, item ID(s), quantity, subtotal, total, dates, dispatch-by. Buyer names and addresses are <b>not</b> exported. Paste order numbers (like <code>17-15362-92949</code>) or item IDs to export only those.',
    placeholder: '17-15362-92949\n287570906024',
  },
};

const $ = (id) => document.getElementById(id);
let mode = 'quantity';
let items = [];
let previewed = false;
let running = false;
let stopFlag = false;
let logLines = [];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function log(msg) {
  logLines.push(new Date().toLocaleTimeString() + '  ' + msg);
  $('log').textContent = logLines.join('\n');
  $('log').scrollTop = $('log').scrollHeight;
}
async function getTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}
const isEbay = (tab) => !!tab && /^https:\/\/www\.ebay\.(co\.uk|com)\//.test(tab.url || '');
const pathOf = (tab) => new URL(tab.url).pathname.replace(/\/+$/, '');
function onRightPage(tab) {
  const m = MODES[mode];
  if (!isEbay(tab)) return false;
  const p = pathOf(tab);
  return m.exact ? p === m.page : p.startsWith(m.page);
}
async function updateTabStatus() {
  const tab = await getTab();
  const el = $('tabStatus');
  if (!isEbay(tab)) { el.textContent = 'Open eBay Seller Hub in this tab to use the tool.'; return; }
  const m = MODES[mode];
  if (selfNav(mode)) { el.textContent = 'Ready (the tool opens the pages it needs).'; return; }
  el.textContent = onRightPage(tab) ? 'Ready: on the right page.' : 'This action needs ' + m.page + ' (click "Open correct page").';
}
async function inject(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['logic.js', 'pagelib.js'] });
}
async function callPage(tabId, fn, ...args) {
  const res = await chrome.scripting.executeScript({
    target: { tabId },
    func: (name, a) => window.__ebz[name](...a),
    args: [fn, args],
  });
  return res && res[0] ? res[0].result : null;
}
async function goTo(tab, url) {
  await chrome.tabs.update(tab.id, { url });
  await sleep(1200);
  await waitTabComplete(tab.id);
  await sleep(1500);
}
async function waitTabComplete(tabId, timeout = 40000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    const t = await chrome.tabs.get(tabId);
    if (t.status === 'complete') return true;
    await sleep(300);
  }
  return false;
}
function download(name, text, type) {
  const blob = new Blob([text], { type: type || 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
const today = () => new Date().toISOString().slice(0, 10);

// ---------- rendering ----------
function render() {
  const m = MODES[mode];
  const tb = $('table').querySelector('tbody');
  tb.innerHTML = '';
  items.forEach((it) => {
    const tr = document.createElement('tr');
    const cls = { ok: 'ok', error: 'bad', skipped: 'warn', running: 'run', warn: 'warn' }[it.status] || '';
    tr.innerHTML = '<td></td><td></td><td></td><td class="' + cls + '"></td>';
    tr.children[0].innerHTML = '<div></div><div class="title"></div>';
    tr.children[0].children[0].textContent = it.id;
    tr.children[0].children[1].textContent = (it.text ? '[' + it.text + '] ' : '') + (it.title || '');
    tr.children[1].textContent = it.now || '';
    tr.children[2].textContent = it.newText || (m.needsValue ? it.value : mode === 'end' ? 'END' : mode === 'relist' ? 'RELIST' : '');
    tr.children[3].textContent = (it.status === 'pending' ? '' : it.status.toUpperCase() + ' ') + (it.msg || '');
    tb.appendChild(tr);
  });
  const done = items.filter((i) => ['ok', 'error', 'skipped'].includes(i.status)).length;
  $('barFill').style.width = items.length ? (100 * done / items.length) + '%' : '0';
}
function resetReview() {
  previewed = false; $('reviewed').checked = false; $('runBtn').disabled = true; $('retryBtn').disabled = true;
}
function setMode(m) {
  if (running) return;
  mode = m;
  const cfg = MODES[m];
  $('modeSel').value = m;
  $('help').innerHTML = cfg.help;
  $('inputLabel').textContent = cfg.label;
  $('input').placeholder = cfg.placeholder;
  const isExport = cfg.kind === 'export';
  $('runBlock').classList.toggle('hide', isExport);
  $('delayWrap').classList.toggle('hide', isExport);
  $('previewBtn').textContent = isExport ? 'Export CSV' : '1. Preview';
  $('inputCard').classList.toggle('hide', isExport && m !== 'exportOrders');
  $('goPage').classList.toggle('hide', false);
  $('undoBtn').classList.toggle('hide', !['quantity', 'price', 'adrate'].includes(m));
  $('rulesCard').classList.toggle('hide', !cfg.rules);
  $('campCard').classList.toggle('hide', m !== 'campNew');
  $('loadCampBtn').classList.toggle('hide', m !== 'campEnd' && m !== 'campPause');
  $('r_allWrap').classList.toggle('hide', m !== 'campNew');
  $('r_all').checked = false;
  $('r_promoted').value = m === 'campNew' ? 'no' : '';
  $('r_valueWrap').classList.toggle('hide', !cfg.needsValue);
  $('r_value').placeholder = cfg.valueHint || '';
  $('r_skipVar').checked = !!cfg.skipVarDefault;
  items = []; resetReview();
  $('summary').textContent = ''; $('ruleResult').textContent = '';
  render(); updateTabStatus();
}

// ---------- preview ----------
async function preview() {
  const tab = await getTab();
  if (!isEbay(tab)) { $('summary').textContent = 'Open eBay Seller Hub first.'; return; }
  const m = MODES[mode];
  if (m.kind === 'export') return doExport(tab);
  const { items: parsed, problems } = L.parseInput($('input').value, mode);
  items = parsed; resetReview();
  problems.forEach((p) => log('Input: ' + p));
  if (!items.length) { $('summary').textContent = 'Nothing valid to run.' + (problems.length ? ' See the log for details.' : ''); render(); return; }
  let note = '';
  if (mode === 'campNew') {
    const name = $('c_name').value.trim();
    const rateMode = $('c_rateMode').value;
    const rate = $('c_rate').value.trim().replace('%', '');
    const issues = [];
    if (!name) issues.push('Enter a campaign name.');
    if (rateMode === 'fixed' && !(L.normaliseRate(rate) && L.normaliseRate(rate) !== 'dynamic')) issues.push('Fixed ad rate must be a number from 2 to 100.');
    if (issues.length) { items = []; $('summary').textContent = issues.join(' '); render(); return; }
    const ids = items.map((i) => i.id);
    items = [{
      id: 'NEW CAMPAIGN', text: '', value: '', ids, title: name + ' - ' + ids.length + ' listings', now: '',
      newText: rateMode === 'fixed' ? rate + '% fixed' : 'dynamic rate', status: 'pending',
      msg: $('c_stop').checked ? 'will fill the form, then STOP before Launch' : 'will LAUNCH the campaign', msg0: '',
    }];
    note = 'eBay only accepts listings that are not already in another campaign; the result reports how many were accepted.';
  } else if (mode === 'campEnd' || mode === 'campPause') {
    await goTo(tab, new URL(tab.url).origin + CAMPS);
    await inject(tab.id);
    const info = await callPage(tab.id, 'scanCampaigns');
    const byId = {};
    ((info && info.rows) || []).forEach((r) => { byId[r.id] = r; });
    let found = 0;
    items.forEach((it) => {
      const d = byId[it.id];
      if (!d) { it.status = 'warn'; it.msg = 'campaign not found on the campaigns page'; return; }
      found++;
      it.title = d.name + (d.type ? ' (' + d.type + ')' : '');
      it.now = d.status;
      it.newText = mode === 'campEnd' ? 'END' : 'PAUSE';
      if (/ended/i.test(d.status)) { it.status = 'warn'; it.msg = 'already ended'; }
      else if (mode === 'campPause' && /paused/i.test(d.status)) { it.status = 'warn'; it.msg = 'already paused'; }
    });
    note = found + ' of ' + items.length + ' campaigns found.';
  } else if (mode === 'relist') {
    items.forEach((it) => { it.msg = 'will open relist form'; });
    note = 'Relist cannot be previewed in detail; each form is opened and submitted one by one.';
  } else if (mode === 'varqty' || mode === 'varprice') {
    items.forEach((it) => { it.msg = it.text ? 'matching variations only' : 'ALL variations'; it.newText = it.value; });
    note = 'Each listing\'s variation page is opened and edited row by row.';
  } else {
    if (!onRightPage(tab)) { $('summary').textContent = 'Go to the Active listings page first ("Open correct page").'; render(); return; }
    await inject(tab.id);
    const info = await callPage(tab.id, 'inspect', items.map((i) => i.id));
    let found = 0;
    items.forEach((it) => {
      const d = info && info[it.id];
      if (!d || !d.found) { it.status = 'warn'; it.msg = 'not on this page - will search for it'; return; }
      found++;
      it.title = d.title;
      if (mode === 'quantity') {
        it.now = d.qty;
        if (d.variations) { it.status = 'warn'; it.msg = 'variation listing - will be skipped'; }
        else if (d.qty === it.value) it.msg = 'already this quantity';
        if (it.value === '0') it.msg = (it.msg ? it.msg + '; ' : '') + 'quantity 0 = out of stock';
      } else if (mode === 'price') {
        it.now = d.priceText || '';
        if (d.variations || d.price == null) { it.status = 'warn'; it.msg = 'variation/range price - will be skipped'; return; }
        const np = L.calcPrice(d.price, it.value);
        if (np == null) { it.status = 'warn'; it.msg = 'cannot calculate a valid price'; return; }
        it.newText = '£' + np.toFixed(2) + (/^[+-]/.test(it.value) ? ' (' + it.value + ')' : '');
        if (Math.abs(np - d.price) < 0.005) it.msg = 'no change';
        else if (Math.abs(np - d.price) / d.price > 0.5) { it.status = 'warn'; it.msg = 'BIG change (' + Math.round(100 * (np - d.price) / d.price) + '%)'; }
      } else if (mode === 'adrate') {
        it.now = d.adRate ? d.adRate + '%' : 'not promoted';
        it.newText = it.value === 'dynamic' ? 'dynamic' : it.value + '%';
        if (!d.promoted) { it.status = 'warn'; it.msg = 'not currently promoted - may fail'; }
      } else if (mode === 'adsuggest') {
        it.now = d.adRate ? d.adRate + '%' : 'not promoted';
        if (d.suggested) it.newText = d.suggested + '%';
        else { it.status = 'warn'; it.msg = 'no suggested rate shown - will be skipped'; }
        if (d.suggested && d.adRate && Number(d.suggested) === Number(d.adRate)) it.msg = 'already at suggested rate';
      } else if (mode === 'end') {
        it.now = 'qty ' + d.qty + ', sold ' + (d.sold == null ? '?' : d.sold);
      }
    });
    note = found + ' of ' + items.length + ' found on this page.';
  }
  previewed = true;
  $('summary').textContent = items.length + ' item(s). ' + note;
  render();
  log('Preview ready: ' + items.length + ' item(s) for "' + mode + '".');
}

// ---------- find by rule ----------
async function findByRule() {
  const tab = await getTab();
  if (!isEbay(tab) || pathOf(tab) !== LIST) { $('ruleResult').textContent = 'Open the Active listings page first ("Open correct page").'; return; }
  const m = MODES[mode];
  const value = $('r_value').value.trim();
  if (m.needsValue) {
    const probe = L.parseInput('100000000000, ' + value, mode);
    if (!probe.items.length) { $('ruleResult').textContent = 'Fill in "Value to apply" correctly first (' + (m.valueHint || '') + ').'; return; }
  }
  await inject(tab.id);
  const res = await callPage(tab.id, 'scan');
  if (!res || !res.rows) { $('ruleResult').textContent = 'Could not read the listings table.'; return; }
  const f = {
    titleHas: $('r_title').value.trim(),
    qtyMin: $('r_qtyMin').value, qtyMax: $('r_qtyMax').value,
    viewsMin: $('r_viewsMin').value, viewsMax: $('r_viewsMax').value,
    soldMin: $('r_soldMin').value, soldMax: $('r_soldMax').value,
    priceMin: $('r_priceMin').value, priceMax: $('r_priceMax').value,
    promoted: $('r_promoted').value, skipVar: $('r_skipVar').checked, combine: $('r_combine').value,
  };
  const useAll = mode === 'campNew' && $('r_all').checked;
  const noFilter = !f.titleHas && !f.qtyMin && !f.qtyMax && !f.viewsMin && !f.viewsMax && !f.soldMin && !f.soldMax && !f.priceMin && !f.priceMax && !f.promoted;
  if (noFilter && !useAll) { $('ruleResult').textContent = 'Set at least one rule first (otherwise every listing would match).'; return; }
  const hits = useAll
    ? res.rows.filter((r) => L.matchesRule(r, { skipVar: f.skipVar, promoted: f.promoted }))
    : res.rows.filter((r) => L.matchesRule(r, f));
  $('input').value = hits.map((r) => r.id + (m.needsValue ? ', ' + value : '')).join('\n');
  resetReview();
  let msg = hits.length + ' of ' + res.rows.length + ' listings matched.';
  if (res.total && res.total > res.rows.length) msg += ' WARNING: this page shows only ' + res.rows.length + ' of ' + res.total + ' listings - set "Results per page" higher or check other pages.';
  if (hits.length) msg += ' Now press Preview.';
  $('ruleResult').textContent = msg;
  log('Rule search: ' + msg);
}

// ---------- export ----------
async function doExport(tab) {
  if (!onRightPage(tab)) { $('summary').textContent = 'Open the correct page first ("Open correct page").'; return; }
  await inject(tab.id);
  if (mode === 'exportActive') {
    const res = await callPage(tab.id, 'scan');
    const cols = [
      { key: 'id', label: 'Item ID' }, { key: 'title', label: 'Title' }, { key: 'sku', label: 'Custom label (SKU)' },
      { key: 'priceText', label: 'Price' }, { key: 'qty', label: 'Available quantity' }, { key: 'views', label: 'Views (30 days)' },
      { key: 'sold', label: 'Sold' }, { key: 'watchers', label: 'Watchers' }, { key: 'adRate', label: 'Ad rate %' },
      { key: 'suggested', label: 'Suggested ad rate %' }, { key: 'variationsText', label: 'Has variations' },
    ];
    const rows = res.rows.map((r) => Object.assign({}, r, { variationsText: r.variations ? 'yes' : 'no' }));
    download('ebay-active-listings-' + today() + '.csv', L.toCsv(rows, cols));
    let msg = 'Exported ' + rows.length + ' active listings.';
    if (res.total && res.total > rows.length) msg += ' Only ' + rows.length + ' of ' + res.total + ' are loaded on this page - raise "Results per page" and export again for the rest.';
    $('summary').textContent = msg; log(msg);
  } else if (mode === 'exportEnded') {
    const res = await callPage(tab.id, 'scanEnded');
    const cols = [
      { key: 'id', label: 'Item ID' }, { key: 'title', label: 'Title' }, { key: 'sku', label: 'Custom label (SKU)' },
      { key: 'format', label: 'Format' }, { key: 'price', label: 'Price' }, { key: 'qty', label: 'Available quantity' },
      { key: 'views', label: 'Views' }, { key: 'watchers', label: 'Watchers' }, { key: 'endDate', label: 'End date' },
      { key: 'soldStatus', label: 'Sold status' }, { key: 'relistStatus', label: 'Relist status' },
    ];
    download('ebay-ended-listings-' + today() + '.csv', L.toCsv(res.rows, cols));
    const msg = 'Exported ' + res.rows.length + ' ended listings (rows loaded on this page).';
    $('summary').textContent = msg; log(msg);
  } else {
    const res = await callPage(tab.id, 'scanOrders');
    const tokens = $('input').value.split(/[\s,;]+/).map((s) => s.trim()).filter(Boolean);
    let rows = res.rows;
    if (tokens.length) rows = rows.filter((r) => tokens.some((t) => r.orderNo === t || r.itemIds.split(' ').includes(t)));
    const cols = [
      { key: 'orderNo', label: 'Order number' }, { key: 'itemIds', label: 'Item ID(s)' }, { key: 'quantity', label: 'Quantity' },
      { key: 'subtotal', label: 'Subtotal' }, { key: 'total', label: 'Total' }, { key: 'dateSold', label: 'Date sold' },
      { key: 'datePaid', label: 'Date paid' }, { key: 'dispatchBy', label: 'Dispatch by' },
    ];
    if (!rows.length) { $('summary').textContent = tokens.length ? 'No loaded order matched those numbers (try another page/filter).' : 'No orders found on this page.'; return; }
    download('ebay-orders-' + today() + '.csv', L.toCsv(rows, cols));
    const msg = 'Exported ' + rows.length + ' order(s) from this page.';
    $('summary').textContent = msg; log(msg);
  }
}

// ---------- run ----------
async function runOne(tab, it) {
  const origin = new URL(tab.url).origin;
  if (mode === 'relist') {
    await chrome.tabs.update(tab.id, { url: origin + '/sl/list?mode=RelistItem&itemId=' + it.id });
    await sleep(1200);
    await waitTabComplete(tab.id);
    await inject(tab.id);
    const prep = await callPage(tab.id, 'relistPrepare');
    if (!prep || !prep.ok) return { ok: false, msg: (prep && prep.msg) || 'form not ready' };
    const err0 = await callPage(tab.id, 'relistErrors');
    let sub;
    try { sub = await callPage(tab.id, 'relistSubmit'); } catch (e) { sub = { ok: true }; }
    if (!sub || !sub.ok) return { ok: false, msg: (sub && sub.msg) || 'submit failed' };
    const t0 = Date.now();
    while (Date.now() - t0 < 40000) {
      await sleep(1500);
      let t; try { t = await chrome.tabs.get(tab.id); } catch (e) { return { ok: false, msg: 'tab closed' }; }
      const u = new URL(t.url);
      if (u.pathname !== '/sl/list') return { ok: true, msg: 'Submitted -> ' + u.pathname };
      try {
        const err = await callPage(tab.id, 'relistErrors');
        if (err && err !== err0) return { ok: false, msg: 'eBay says: ' + err };
      } catch (e) { /* page navigating */ }
    }
    return { ok: false, msg: 'No confirmation after 40s - check Seller Hub' };
  }
  if (mode === 'campEnd' || mode === 'campPause') {
    await goTo(tab, origin + CAMPS);
    await inject(tab.id);
    return await callPage(tab.id, 'campAction', it.id, mode === 'campEnd' ? 'End' : 'Pause');
  }
  if (mode === 'campNew') {
    await goTo(tab, origin + NEWCAMP);
    await inject(tab.id);
    const rateMode = $('c_rateMode').value;
    const res = await callPage(tab.id, 'campCreate', {
      ids: it.ids, name: $('c_name').value.trim(), rateMode,
      rate: String(Number($('c_rate').value.trim().replace('%', ''))),
    });
    if (!res || !res.ok) return res || { ok: false, msg: 'no response from page' };
    if ($('c_stop').checked) return { ok: true, msg: res.msg + ' STOPPED before Launch - press Launch in eBay.' };
    try { await callPage(tab.id, 'campLaunch'); } catch (e) { /* page may navigate */ }
    const t0 = Date.now();
    while (Date.now() - t0 < 45000) {
      await sleep(1500);
      let t; try { t = await chrome.tabs.get(tab.id); } catch (e) { return { ok: false, msg: 'tab closed' }; }
      if (new URL(t.url).pathname.replace(/\/+$/, '') !== NEWCAMP) return { ok: true, msg: 'Launched (' + res.msg + ')' };
      try {
        const p = await callPage(tab.id, 'campPoll');
        if (p && (p.state === 'error' || p.state === 'popup')) return { ok: false, msg: 'eBay says: ' + p.msg };
      } catch (e) { /* navigating */ }
    }
    return { ok: false, msg: 'No confirmation after 45s - check the campaigns page' };
  }
  if (mode === 'varqty' || mode === 'varprice') {
    await chrome.tabs.update(tab.id, { url: origin + LIST + '/' + it.id });
    await sleep(1200);
    await waitTabComplete(tab.id);
    await inject(tab.id);
    return await callPage(tab.id, 'varEdit', mode === 'varqty' ? 'qty' : 'price', it.text, it.value);
  }
  await inject(tab.id);
  if (mode === 'adsuggest') return await callPage(tab.id, 'adsuggest', it.id);
  return await callPage(tab.id, mode, it.id, it.value);
}

async function run() {
  if (running || !previewed) return;
  const tab = await getTab();
  if (!isEbay(tab)) return;
  if (!selfNav(mode) && !onRightPage(tab)) {
    $('summary').textContent = 'The tab moved away from the Active listings page. Click "Open correct page", then Preview again.';
    resetReview(); return;
  }
  const todo = items.filter((i) => i.status !== 'ok');
  if (!todo.length) return;
  const verb = { quantity: 'update the quantity of', price: 'change the price of', adrate: 'change the ad rate of', adsuggest: 'apply the suggested ad rate to',
    varqty: 'change variation quantities in', varprice: 'change variation prices in', end: 'END', relist: 'RELIST',
    campNew: $('c_stop').checked ? 'build a new campaign form (it will NOT be launched) with' : 'CREATE AND LAUNCH a Promoted Listings campaign (ad fees apply) with',
    campEnd: 'END (permanently)', campPause: 'PAUSE' }[mode];
  const noun = isCamp(mode) && mode !== 'campNew' ? 'campaign(s)' : mode === 'campNew' ? 'listing(s) (' + (todo[0] && todo[0].ids ? todo[0].ids.length : 0) + ' selected)' : 'listing(s)';
  const count = mode === 'campNew' ? '' : todo.length + ' ';
  if (!window.confirm('About to ' + verb + ' ' + count + noun + ' on your live eBay account.\n\nProceed?')) return;
  running = true; stopFlag = false;
  $('runBtn').disabled = true; $('previewBtn').disabled = true; $('stopBtn').disabled = false; $('retryBtn').disabled = true;
  $('modeSel').disabled = true;
  const delay = Math.max(1, Number($('delay').value) || 2) * 1000;
  log('--- RUN START: ' + mode + ' (' + todo.length + ' items) ---');
  for (const it of todo) {
    if (stopFlag) { log('Stopped by user.'); break; }
    it.status = 'running'; it.msg = ''; render();
    let res;
    try { res = await runOne(tab, it); } catch (e) { res = { ok: false, msg: 'Error: ' + (e.message || e) }; }
    it.status = res && res.ok ? 'ok' : 'error';
    it.msg = (res && res.msg) || '';
    it.before = res && res.before != null ? String(res.before) : null;
    log((it.status === 'ok' ? 'OK    ' : 'FAIL  ') + it.id + (it.text ? ' [' + it.text + ']' : '') + '  ' + it.msg);
    render();
    if (stopFlag) { log('Stopped by user.'); break; }
    await sleep(delay + Math.random() * 600);
  }
  const ok = items.filter((i) => i.status === 'ok').length, bad = items.filter((i) => i.status === 'error').length;
  log('--- RUN END: ' + ok + ' ok, ' + bad + ' failed, ' + items.filter((i) => i.status === 'pending').length + ' not run ---');
  await saveUndo();
  running = false;
  $('modeSel').disabled = false; $('previewBtn').disabled = false; $('stopBtn').disabled = true;
  $('reviewed').checked = false; $('runBtn').disabled = true;
  $('retryBtn').disabled = !(bad || items.some((i) => i.status === 'pending'));
  $('summary').textContent = 'Done: ' + ok + ' ok, ' + bad + ' failed. Failed rows show the reason in the Status column.' +
    (['quantity', 'price', 'adrate'].includes(mode) ? ' Use "Load undo list" to reverse the changes.' : '');
}

// ---------- undo / retry ----------
async function saveUndo() {
  if (!['quantity', 'price', 'adrate'].includes(mode)) return;
  const lines = items
    .filter((i) => i.status === 'ok' && i.before != null && i.before !== '' && !/^Already/i.test(i.msg))
    .map((i) => i.id + ', ' + i.before);
  if (!lines.length) return;
  try { await chrome.storage.local.set({ lastUndo: { mode, time: Date.now(), lines } }); log('Undo list saved (' + lines.length + ' items).'); } catch (e) { /* ignore */ }
}
async function loadUndo() {
  let data;
  try { data = (await chrome.storage.local.get('lastUndo')).lastUndo; } catch (e) { data = null; }
  if (!data || !data.lines || !data.lines.length) { $('summary').textContent = 'No undo list saved yet.'; return; }
  if (data.mode !== mode) setMode(data.mode);
  $('input').value = data.lines.join('\n');
  resetReview();
  $('summary').textContent = 'Loaded undo list for "' + data.mode + '" (' + data.lines.length + ' items, from ' + new Date(data.time).toLocaleString() + '). Press Preview, then Confirm & Run to reverse.';
  log('Loaded undo list (' + data.lines.length + ').');
}
function retryFailed() {
  items.forEach((i) => { if (i.status === 'error') { i.status = 'pending'; i.msg = ''; } });
  render();
  $('retryBtn').disabled = true;
  $('summary').textContent = 'Failed items reset. Tick "I reviewed..." and run again.';
}

// ---------- load campaigns ----------
async function loadCampaigns() {
  const tab = await getTab();
  if (!isEbay(tab)) { $('summary').textContent = 'Open eBay Seller Hub first.'; return; }
  await goTo(tab, new URL(tab.url).origin + CAMPS);
  await inject(tab.id);
  const res = await callPage(tab.id, 'scanCampaigns');
  const rows = (res && res.rows) || [];
  const usable = rows.filter((r) => !/ended/i.test(r.status) && !(mode === 'campPause' && /paused/i.test(r.status)));
  $('input').value = usable.map((r) => r.id).join('\n');
  items = []; resetReview(); render();
  $('summary').textContent = rows.length
    ? 'Found ' + rows.length + ' campaign(s); loaded ' + usable.length + ': ' + usable.map((r) => (r.name || r.id) + ' [' + r.status + ']').join(', ') + '. Press Preview.'
    : 'No campaigns found on the page (it may still be loading - try again).';
  log('Loaded campaigns: ' + rows.map((r) => r.id + ' ' + r.name + ' ' + r.status).join('; '));
}

// ---------- events ----------
$('loadCampBtn').addEventListener('click', async () => { if (running) return; try { await loadCampaigns(); } catch (e) { $('summary').textContent = 'Error: ' + (e.message || e); } });
$('c_rateMode').addEventListener('change', () => { $('c_rateWrap').classList.toggle('hide', $('c_rateMode').value !== 'fixed'); resetReview(); });
['c_name', 'c_rate', 'c_stop'].forEach((id) => $(id).addEventListener('input', resetReview));
$('c_stop').addEventListener('change', resetReview);
$('modeSel').addEventListener('change', (e) => setMode(e.target.value));
$('previewBtn').addEventListener('click', async () => { if (running) return; try { await preview(); } catch (e) { $('summary').textContent = 'Error: ' + (e.message || e); log('Error: ' + (e.message || e)); } });
$('findBtn').addEventListener('click', async () => { try { await findByRule(); } catch (e) { $('ruleResult').textContent = 'Error: ' + (e.message || e); } });
$('runBtn').addEventListener('click', run);
$('stopBtn').addEventListener('click', () => { stopFlag = true; $('stopBtn').disabled = true; log('Stop requested - finishing current item...'); });
$('retryBtn').addEventListener('click', retryFailed);
$('undoBtn').addEventListener('click', loadUndo);
$('reviewed').addEventListener('change', () => { $('runBtn').disabled = !($('reviewed').checked && previewed && !running); });
$('input').addEventListener('input', resetReview);
$('csv').addEventListener('change', async (e) => {
  const f = e.target.files[0]; if (!f) return;
  $('input').value = await f.text();
  e.target.value = ''; resetReview();
  log('Loaded file: ' + f.name);
});
$('goPage').addEventListener('click', async () => {
  const tab = await getTab();
  const page = (mode.startsWith('var') ? LIST : MODES[mode].page);
  if (!isEbay(tab)) { window.open('https://www.ebay.co.uk' + page); return; }
  await chrome.tabs.update(tab.id, { url: new URL(tab.url).origin + page });
});
$('clearLog').addEventListener('click', () => { logLines = []; $('log').textContent = ''; });
$('dlLog').addEventListener('click', () => download('ebay-automator-log-' + Date.now() + '.txt', logLines.join('\n'), 'text/plain'));
chrome.tabs.onActivated.addListener(updateTabStatus);
chrome.tabs.onUpdated.addListener((id, info) => { if (info.status === 'complete') updateTabStatus(); });

setMode('quantity');
