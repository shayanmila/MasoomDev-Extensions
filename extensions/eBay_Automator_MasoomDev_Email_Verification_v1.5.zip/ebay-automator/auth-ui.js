const $=id=>document.getElementById(id);
let pendingEmail='';
function status(t){$('status').textContent=t;}
function busy(v){for(const id of ['signIn','signUp','verify','resend'])$(id).disabled=v;}
function showVerify(email){pendingEmail=email;$('verifyArea').hidden=false;$('accountArea').hidden=true;status('Enter the verification code sent to '+email+'.');}
(async()=>{if(await MasoomAuth.validSession())location.replace('sidepanel.html');else if(!MasoomAuth.configured())status('Supabase configuration is missing.');})();
async function auth(mode){
 const email=$('email').value.trim(),password=$('password').value;
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return status('Enter a valid email.');
 if(!password||password.length<8)return status('Password must have at least 8 characters.');
 busy(true);status('Please wait...');
 try{
  const data=await MasoomAuth.request(mode==='signup'?'/signup':'/token?grant_type=password','POST',{email,password});
  if(data.access_token&&data.refresh_token){await MasoomAuth.saveSession(data);location.replace('sidepanel.html');return;}
  if(mode==='signup'){showVerify(email);return;}
  status('Sign-in did not return a session. Check that your email is confirmed.');
 }catch(e){status(e.message)}finally{busy(false)}
}
$('signIn').onclick=()=>auth('signin');
$('signUp').onclick=()=>auth('signup');
$('verify').onclick=async()=>{
 const token=$('otp').value.trim();if(!/^\d{6,8}$/.test(token))return status('Enter the numeric code from your email.');
 busy(true);status('Verifying code...');
 try{
  const data=await MasoomAuth.request('/verify','POST',{email:pendingEmail,token,type:'signup'});
  if(data.access_token&&data.refresh_token){await MasoomAuth.saveSession(data);location.replace('sidepanel.html');return;}
  status('Email confirmed. Please sign in with your email and password.');$('verifyArea').hidden=true;$('accountArea').hidden=false;
 }catch(e){status(e.message)}finally{busy(false)}
};
$('resend').onclick=async()=>{
 busy(true);status('Requesting another code...');
 try{await MasoomAuth.request('/resend','POST',{type:'signup',email:pendingEmail});status('If permitted by Supabase rate limits, a new code has been sent. Check inbox and spam.');}
 catch(e){status(e.message)}finally{busy(false)}
};
$('back').onclick=()=>{$('verifyArea').hidden=true;$('accountArea').hidden=false;status('');};
