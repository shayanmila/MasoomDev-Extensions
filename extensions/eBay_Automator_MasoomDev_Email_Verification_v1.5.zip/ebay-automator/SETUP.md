# MasoomDev eBay Automator v1.5 — Supabase signup verification

Supabase project: uuvqawlqcnrcdribwava

1. In Supabase Authentication > Providers > Email, enable Email and Confirm Email. Ensure new signups are allowed.
2. In Authentication > Email Templates > Confirm Signup, include `{{ .Token }}` (numeric verification code) rather than a confirmation URL. Save template.
3. Ensure custom SMTP (Resend, verified masoomdev.online domain) is working. Sender: noreply@masoomdev.online.
4. Extract ZIP and load `ebay-automator` folder using Chrome > chrome://extensions > Developer mode > Load unpacked. Remove/disable the older extension if needed.
5. New user: enter email and password, Sign Up, then enter emailed code and Verify Email. Existing verified user: Sign In directly.
6. If rate limited, wait before requesting another code. Verify from the extension, not the previous localhost:3000 magic link.

No secret/service-role key is stored in the extension. The publishable key is expected to be public.

Note: This is client-side authentication, not tamper-proof licensing. Supabase settings are shared across all apps using this project. Automation scripts were not modified. Test signup, sign-in, session restore, sign-out, and all eBay automation actions before production release. No live end-to-end test was performed.
