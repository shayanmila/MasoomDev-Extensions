(() => {
  'use strict';
  const ID='__ebay_fee_sidebar_host_v1';
  if(document.getElementById(ID))return;
  const root=document.documentElement;
  const body=document.body;
  if(!body)return;
  const host=document.createElement('div');
  host.id=ID;
  host.style.cssText='position:fixed!important;right:0!important;top:0!important;height:100vh!important;z-index:2147483647!important;margin:0!important;padding:0!important;border:0!important;box-shadow:-4px 0 20px #0002!important;background:#fff!important;';
  const shadow=host.attachShadow({mode:'closed'});
  const wrapper=document.createElement('div');
  wrapper.style.cssText='position:relative;width:100%;height:100%;';
  const iframe=document.createElement('iframe');
  iframe.src=chrome.runtime.getURL('panel.html');
  iframe.title='eBay Fee and Profit Calculator';
  iframe.style.cssText='display:block;width:100%;height:100%;border:0;background:#fff;';
  const grip=document.createElement('div');
  grip.title='Drag left or right to resize calculator';
  grip.setAttribute('role','separator');
  grip.setAttribute('aria-label','Resize calculator sidebar');
  grip.setAttribute('aria-orientation','vertical');
  grip.setAttribute('tabindex','0');
  grip.style.cssText='position:absolute;left:-7px;top:0;bottom:0;width:14px;cursor:col-resize;z-index:2;touch-action:none;background:transparent;';
  const line=document.createElement('div');
  line.style.cssText='position:absolute;left:6px;top:calc(50% - 28px);width:5px;height:56px;border-radius:5px;background:#2388dc;box-shadow:0 0 0 3px #fff,0 2px 8px #0004;';
  grip.appendChild(line);
  wrapper.append(iframe,grip);shadow.appendChild(wrapper);
  const saved=new Map();
  function remember(el,property){
    if(!el)return;
    saved.set(el===root?'html:'+property:'body:'+property,{
      el,property,value:el.style.getPropertyValue(property),priority:el.style.getPropertyPriority(property)
    });
  }
  // The page gets a reduced layout viewport. We also set body width to avoid
  // full-viewport content sitting underneath the sidebar.
  for(const el of [root,body])for(const prop of ['width','max-width','min-width','margin-right','box-sizing'])remember(el,prop);
  let width=390;
  let dragging=false;
  const clamp=n=>Math.max(240,Math.min(Math.max(240,window.innerWidth-160),n));
  function apply(){
    width=clamp(width);
    host.style.setProperty('width',width+'px','important');
    for(const el of [root,body]){
      el.style.setProperty('width',`calc(100% - ${width}px)`,'important');
      el.style.setProperty('max-width',`calc(100% - ${width}px)`,'important');
      el.style.setProperty('min-width','0','important');
      el.style.setProperty('box-sizing','border-box','important');
    }
    // Many eBay page sections calculate their widths from body.
    // Avoid adding right margin: that can double-shrink nested layouts.
    root.style.setProperty('margin-right',width+'px','important');
    body.style.setProperty('margin-right','0','important');
    grip.setAttribute('aria-valuenow',String(width));
  }
  function restore(){
    for(const {el,property,value,priority} of saved.values()){
      if(value)el.style.setProperty(property,value,priority);
      else el.style.removeProperty(property);
    }
  }
  function endDrag(){
    if(!dragging)return;
    dragging=false;
    document.removeEventListener('pointermove',move,true);
    document.removeEventListener('pointerup',endDrag,true);
    document.removeEventListener('pointercancel',endDrag,true);
    iframe.style.pointerEvents='';
    chrome.storage.local.set({ebayFeeSidebarWidth:width}).catch(()=>{});
  }
  function move(e){if(!dragging)return;width=window.innerWidth-e.clientX;apply();e.preventDefault()}
  grip.addEventListener('pointerdown',e=>{
    if(e.button!==0)return;
    dragging=true;
    iframe.style.pointerEvents='none';
    document.addEventListener('pointermove',move,true);
    document.addEventListener('pointerup',endDrag,true);
    document.addEventListener('pointercancel',endDrag,true);
    e.preventDefault();
  });
  grip.addEventListener('keydown',e=>{
    if(!['ArrowLeft','ArrowRight'].includes(e.key))return;
    width+=e.key==='ArrowLeft'?20:-20;
    apply();chrome.storage.local.set({ebayFeeSidebarWidth:width}).catch(()=>{});
    e.preventDefault();
  });
  (document.documentElement||document.body).appendChild(host);
  chrome.storage.local.get('ebayFeeSidebarWidth').then(r=>{
    if(!document.getElementById(ID))return;
    width=Number(r.ebayFeeSidebarWidth)||390;
    apply();
  }).catch(()=>{});
  apply();
  window.addEventListener('resize',apply);
  const close=()=>{
    endDrag();restore();window.removeEventListener('resize',apply);
    chrome.runtime.onMessage.removeListener(onMessage);
    window.removeEventListener('message',onWindowMessage);
    host.remove();
  };
  const onMessage=msg=>{if(msg?.type==='EBAY_FEE_CLOSE')close()};
  const onWindowMessage=e=>{
    if(e.source!==iframe.contentWindow||e.origin!==new URL(iframe.src).origin)return;
    if(e.data?.type==='EBAY_FEE_EXIT'){
      chrome.runtime.sendMessage({type:'EBAY_FEE_EXIT'}).catch(()=>{});
      close();
    }
  };
  chrome.runtime.onMessage.addListener(onMessage);
  window.addEventListener('message',onWindowMessage);
})();