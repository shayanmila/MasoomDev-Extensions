
const PREFIX='ebayfee:';
const key=id=>PREFIX+id;
async function enabled(id){const d=await chrome.storage.session.get(key(id));return !!d[key(id)]}
async function setEnabled(id,value){if(value)await chrome.storage.session.set({[key(id)]:true});else await chrome.storage.session.remove(key(id))}
async function inject(tabId){
  try{await chrome.scripting.executeScript({target:{tabId,allFrames:false},files:['inject.js']})}
  catch(e){console.warn('Fee calculator injection:',e.message)}
}
chrome.action.onClicked.addListener(async tab=>{
  if(!tab.id||!/^https?:/.test(tab.url||''))return;
  const state=await enabled(tab.id);
  await setEnabled(tab.id,!state);
  if(state)chrome.tabs.sendMessage(tab.id,{type:'EBAY_FEE_CLOSE'}).catch(()=>{});
  else await inject(tab.id);
});
chrome.tabs.onUpdated.addListener((tabId,change,tab)=>{
  if(change.status==='complete'&&/^https?:/.test(tab.url||'')){
    enabled(tabId).then(yes=>{if(yes)inject(tabId)})
  }
});
chrome.tabs.onRemoved.addListener(tabId=>chrome.storage.session.remove(key(tabId)));
chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
  if(msg?.type==='EBAY_FEE_EXIT'&&sender.tab?.id){
    setEnabled(sender.tab.id,false).then(()=>respond({ok:true}));return true;
  }
  if(msg?.type==='EBAY_FEE_TOGGLE_EXIT'){
    chrome.tabs.query({active:true,currentWindow:true},tabs=>{
      const id=tabs[0]?.id;if(id)setEnabled(id,false).then(()=>chrome.tabs.sendMessage(id,{type:'EBAY_FEE_CLOSE'}).catch(()=>{}))
    });
  }
});
