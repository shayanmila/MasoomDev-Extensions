eBay Fee & Profit Calculator v1.0.1
Developed by Masoom Dev

DEFAULT THEME: Clean White / Light

INSTALL
1. Unzip this file.
2. Chrome > chrome://extensions > Developer mode ON > Load unpacked.
3. Select the folder containing manifest.json.
4. Click the extension icon on a normal https:// website to open its sidebar.
5. Click 'Exit' inside the sidebar to close it. It stays open while navigating/reloading the same tab.

IMPORTANT
All rates start at 0% intentionally: eBay UK fees depend on seller account, category, fee policy, ad campaign and VAT treatment. Enter your own rates. These are estimates, not official fee quotations.
The 'Multiplier' applies to PRODUCT COST per unit, not revenue.
The fixed fee and other fixed eBay fee are charged once per order; all other costs are per item as labelled.
No account access, analytics or external API. Settings are saved locally.
Browser-internal pages (chrome://) cannot be injected.

Version 1.0.2: Sidebar reserves page width instead of overlaying eBay content. Closing restores original page width.

Version 1.0.3: Drag the blue handle on the LEFT edge of the sidebar to resize it. Width is saved. Arrow keys also resize when the handle is focused.
