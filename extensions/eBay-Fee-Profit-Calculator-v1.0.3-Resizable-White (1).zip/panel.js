
const ids=['price','charged','qty','multiplier','cost','shipping','other','orderCosts','fvf','fixed','ad','reg','vat','extra'];
const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat('en-GB',{style:'currency',currency:'GBP'}).format(n);
const percent=n=>`${Number.isFinite(n)?n.toFixed(2):'0.00'}%`;
const read=()=>Object.fromEntries(ids.map(id=>[id,Math.max(0,Number($(id).value)||0)]));
let latest='';
function calculate(){
 const d=read(),qty=Math.max(1,Math.floor(d.qty)), revenue=(d.price+d.charged)*qty;
 const productCost=d.cost*d.multiplier*qty,shipCost=d.shipping*qty,otherCost=d.other*qty+d.orderCosts;
 const baseFees=revenue*d.fvf/100,adFee=revenue*d.ad/100,otherPercentFee=revenue*d.reg/100;
 const fixed=d.fixed,extra=d.extra;
 const vatFee=(baseFees+adFee+otherPercentFee+fixed+extra)*d.vat/100;
 const ebayFees=baseFees+adFee+otherPercentFee+fixed+extra+vatFee;
 const costs=productCost+shipCost+otherCost;
 const profit=revenue-ebayFees-costs;
 const margin=revenue?profit/revenue*100:0,roi=costs?profit/costs*100:0;
 $('profit').textContent=money(profit);$('profit').classList.toggle('loss',profit<0);
 for(const [id,value] of Object.entries({revenue:money(revenue),fees:money(ebayFees),adfee:money(adFee),vatfee:money(vatFee),costs:money(costs),margin:percent(margin),roi:percent(roi),perunit:money(profit/qty)}))$(id).textContent=value;
 const rows=[['Buyer total',revenue],['Final value fee',-baseFees],['Promoted listing ad fee',-adFee],['Other percentage fee',-otherPercentFee],['Fixed fee per order',-fixed],['Other fixed eBay fee',-extra],['VAT on eBay fees',-vatFee],['Product cost × multiplier × qty',-productCost],['Your shipping costs',-shipCost],['Packaging / other costs',-otherCost],['Estimated net profit',profit]];
 $('breakdown').replaceChildren(...rows.map(([label,value])=>{const div=document.createElement('div'),a=document.createElement('span'),b=document.createElement('b');a.textContent=label;b.textContent=money(value);div.append(a,b);return div}));
 latest=['eBay Fee & Profit Calculator',...rows.map(([label,value])=>`${label}: ${money(value)}`),`Margin: ${percent(margin)}`,`ROI: ${percent(roi)}`].join('\n');
 chrome.storage.local.set({ebayFeeInputs:d});
}
chrome.storage.local.get('ebayFeeInputs').then(({ebayFeeInputs})=>{
 if(ebayFeeInputs)for(const id of ids)if(ebayFeeInputs[id]!==undefined)$(id).value=ebayFeeInputs[id];
 calculate();
});
for(const id of ids)$(id).addEventListener('input',calculate);
$('copy').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(latest);$('copy').textContent='Copied!';setTimeout(()=>$('copy').textContent='Copy calculation',1200)}catch(e){$('copy').textContent='Copy unavailable'}});
$('reset').addEventListener('click',()=>{for(const id of ids)$(id).value={price:24.99,charged:0,qty:1,multiplier:1,cost:8,shipping:2.5,other:0,orderCosts:0,fvf:0,fixed:0,ad:0,reg:0,vat:0,extra:0}[id];calculate()});
$('exit').addEventListener('click',()=>parent.postMessage({type:'EBAY_FEE_EXIT'},'*'));
