AliExpress Order Filler — MasoomDev v1.4 TEST

Chrome: chrome://extensions -> Developer mode -> Load unpacked (extracted aliexpress-order-filler folder).

Open AliExpress checkout -> Edit shipping address -> open extension side panel.
Paste customer details -> Detect address -> Review -> Fill name, phone & paste address search.

The extension ONLY fills first name, last name and phone, then pastes Street Address + Postcode into the address search box. YOU must select the correct address suggestion manually. It does NOT auto-select suggestions, change region/county/street/postcode fields, save the address, confirm the order, or pay. Check all fields before confirming.

If no suggestions appear, click inside the address search field and adjust the query manually. Never share real customer details in public bug reports.

Version 1.4.1: Address line 2 is filled only into AliExpress Apt/suite/unit optional field; street + postcode only in search. If Apt field is not detected, it is skipped and reported.
