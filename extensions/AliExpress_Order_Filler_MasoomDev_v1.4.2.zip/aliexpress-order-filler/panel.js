const ids=['first','last','country','phone','address1','address2','region','county','city','postcode'];
const el=id=>document.getElementById(id);
const notice=msg=>{el('notice').textContent=msg};
el('parse').addEventListener('click',()=>{if(!el('raw').value.trim())return notice('Paste an address first.');const data=AddressParser.parse(el('raw').value);ids.forEach(id=>el(id).value=data[id]||'');el('review').hidden=false;notice('Address parsed. Review all fields carefully, especially address line 2, region, county and phone.');});
el('clear').addEventListener('click',()=>{el('raw').value='';ids.forEach(id=>el(id).value='');el('review').hidden=true;notice('Cleared.');});
el('fill').addEventListener('click',async()=>{
 const data=Object.fromEntries(ids.map(id=>[id,el(id).value.trim()]));
 if(!data.first||!data.address1||!data.postcode||!data.country)return notice('Missing required fields: first name, street address, postcode or country.');
 if(!/^([A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2})$/i.test(data.postcode)&&/^(united kingdom|uk)$/i.test(data.country))return notice('Check UK postcode format before filling.');
 try{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id||!/^https:\/\/([a-z0-9-]+\.)*aliexpress\.(com|us)\//i.test(tab.url||''))return notice('Open an AliExpress checkout page in the active tab first.');
 const res=await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content.js']});
 const msg=await chrome.tabs.sendMessage(tab.id,{type:'MASOOMDEV_FILL',data});
 notice(msg?.message||'No response from AliExpress form.');
 }catch(e){notice('Unable to fill this page: '+e.message+'\nTry refreshing AliExpress checkout and reopening the shipping address dialog.');}
});
