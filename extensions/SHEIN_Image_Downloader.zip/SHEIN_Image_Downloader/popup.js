const scanBtn = document.getElementById("scan");
const selectAllBtn = document.getElementById("selectAll");
const downloadBtn = document.getElementById("download");
const downloadZipBtn = document.getElementById("downloadZip");
const statusEl = document.getElementById("status");
const countEl = document.getElementById("count");
const listEl = document.getElementById("images");
const productOnlyEl = document.getElementById("productOnly");
const imageFormatEl = document.getElementById("imageFormat");

let images = [];

// Use the high-res URL when it exists; otherwise fall back to the URL found on the page.
async function resolveUrl(item) {
  if (!item.fallback || item.fallback === item.url) return item.url;
  try {
    const res = await fetch(item.url, { method: "HEAD", credentials: "omit", cache: "no-store" });
    if (res.ok) return item.url;
  } catch (_) {}
  return item.fallback;
}

function setStatus(text) { statusEl.textContent = text; }
function selectedImages() {
  return [...listEl.querySelectorAll("input[type=checkbox]:checked")]
    .map(box => images[Number(box.dataset.index)])
    .filter(Boolean);
}
function refreshCount() {
  const selected = selectedImages().length;
  countEl.textContent = `${images.length} images · ${selected} selected`;
  downloadBtn.disabled = selected === 0;
  downloadZipBtn.disabled = selected === 0;
  selectAllBtn.textContent = selected === images.length && images.length ? "Deselect all" : "Select all";
}
function safeName(value) {
  return (value || "shein-image")
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
    .replace(/\s+/g, "-")
    .slice(0, 70);
}
function extensionFromUrl(url) {
  const match = url.match(/\.(jpe?g|png|webp|avif|gif|bmp)(?:[?#]|$)/i);
  return match ? match[1].toLowerCase().replace("jpeg", "jpg") : "jpg";
}
async function fetchImage(item) {
  let lastError;
  for (const url of [...new Set([item.url, item.fallback].filter(Boolean))]) {
    try {
      const response = await fetch(url, {credentials: "omit", cache: "no-store"});
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const blob = await response.blob();
      if (!blob.size) throw new Error("Empty image");
      return {blob, url};
    } catch (err) { lastError = err; }
  }
  throw lastError || new Error("Image unavailable");
}

async function prepareImage(item) {
  const {blob, url} = await fetchImage(item);
  const format = imageFormatEl.value;
  if (format === "original") {
    const mimeExt = {"image/jpeg":"jpg","image/png":"png","image/webp":"webp","image/avif":"avif","image/gif":"gif","image/bmp":"bmp"};
    return {blob, ext:mimeExt[blob.type.split(";")[0]] || extensionFromUrl(url)};
  }
  const bitmap = await createImageBitmap(blob);
  try {
    const canvas = document.createElement("canvas");
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas unavailable");
    if (format === "jpeg") {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0,0,canvas.width,canvas.height);
    }
    ctx.drawImage(bitmap,0,0);
    const mime = format === "jpeg" ? "image/jpeg" : `image/${format}`;
    const output = await new Promise((resolve,reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error("Conversion failed")),mime,0.93));
    if (output.type !== mime) throw new Error("Format not supported");
    return {blob:output,ext:format === "jpeg" ? "jpg" : format};
  } finally { bitmap.close(); }
}

async function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  try {
    await chrome.downloads.download({url,filename,conflictAction:"uniquify",saveAs:false});
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 120000);
  }
}

function renderImages() {
  listEl.replaceChildren();
  images.forEach((item, index) => {
    const tile = document.createElement("div");
    tile.className = "tile";
    const img = document.createElement("img");
    img.loading = "lazy";
    img.src = item.url;
    img.alt = item.alt || `SHEIN image ${index + 1}`;
    img.onerror = () => {
      if (item.fallback && img.src !== item.fallback) { img.src = item.fallback; return; }
      img.alt = "Preview unavailable";
    };
    const label = document.createElement("label");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = true;
    checkbox.dataset.index = String(index);
    checkbox.addEventListener("change", refreshCount);
    const text = document.createElement("span");
    text.textContent = `${index + 1}. ${item.alt || "Product image"}`;
    label.append(checkbox, text);
    tile.append(img, label);
    listEl.append(tile);
  });
  refreshCount();
}

async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !/^https:\/\/([a-z0-9-]+\.)?shein\.co\.uk\//i.test(tab.url || "")) {
    throw new Error("Please open a page on shein.co.uk first.");
  }
  return tab;
}

async function scan() {
  setStatus("Scanning current tab…");
  images = [];
  listEl.replaceChildren();
  try {
    const tab = await getCurrentTab();
    let response;
    try {
      response = await chrome.tabs.sendMessage(tab.id, { type: "SHEIN_COLLECT_IMAGES", scope: productOnlyEl.checked ? "product" : "page" });
    } catch (_) {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      response = await chrome.tabs.sendMessage(tab.id, { type: "SHEIN_COLLECT_IMAGES", scope: productOnlyEl.checked ? "product" : "page" });
    }
    images = (response?.images || []).filter(x => x.url);
    renderImages();
    if (images.length) {
      setStatus(`Found ${images.length} product image${images.length === 1 ? "" : "s"}. Select what you want to save.`);
    } else if (response?.matched === "none") {
      setStatus("Couldn't locate the product gallery. Untick 'Product gallery only' to scan the whole page.");
    } else {
      setStatus("No images found. Scroll the product gallery, then scan again.");
    }
  } catch (err) {
    setStatus(err.message || "Could not scan this page. Refresh SHEIN and try again.");
  }
}

scanBtn.addEventListener("click", scan);
productOnlyEl.addEventListener("change", scan);
selectAllBtn.addEventListener("click", () => {
  const boxes = [...listEl.querySelectorAll("input[type=checkbox]")];
  const shouldCheck = !(boxes.length && boxes.every(b => b.checked));
  boxes.forEach(b => b.checked = shouldCheck);
  refreshCount();
});

downloadBtn.addEventListener("click", async () => {
  const selected = selectedImages();
  if (!selected.length) return;
  downloadBtn.disabled = downloadZipBtn.disabled = true;
  let completed = 0;
  for (let i=0;i<selected.length;i++) {
    try {
      const {blob,ext} = await prepareImage(selected[i]);
      await saveBlob(blob,`SHEIN-Images/${String(i+1).padStart(3,"0")}-${safeName(selected[i].alt || `shein-image-${i+1}`)}.${ext}`);
      completed++;
    } catch(err) { console.warn("Image download failed",err); }
    setStatus(`Downloading: ${i+1}/${selected.length} checked · ${completed} saved`);
  }
  setStatus(`Started ${completed} of ${selected.length} downloads.`);
  refreshCount();
});

/* Minimal ZIP writer (store/no compression). No external library required. */
function crc32(bytes) {
  let crc = -1;
  for (let i = 0; i < bytes.length; i++) {
    crc ^= bytes[i];
    for (let j = 0; j < 8; j++) crc = (crc >>> 1) ^ (crc & 1 ? 0xEDB88320 : 0);
  }
  return (crc ^ -1) >>> 0;
}
function u16(n) { return [n & 255, (n >>> 8) & 255]; }
function u32(n) { return [n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255]; }
function joinBytes(chunks) {
  const total = chunks.reduce((sum, c) => sum + c.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { out.set(chunk, offset); offset += chunk.length; }
  return out;
}
function buildZip(entries) {
  const encoder = new TextEncoder();
  const localChunks = [];
  const centralChunks = [];
  let offset = 0;
  for (const entry of entries) {
    const nameBytes = encoder.encode(entry.name);
    const data = entry.data;
    const crc = crc32(data);
    const local = new Uint8Array([
      ...u32(0x04034b50), ...u16(20), ...u16(0x0800), ...u16(0),
      ...u16(0), ...u16(0), ...u32(crc), ...u32(data.length), ...u32(data.length),
      ...u16(nameBytes.length), ...u16(0)
    ]);
    localChunks.push(local, nameBytes, data);
    const central = new Uint8Array([
      ...u32(0x02014b50), ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0),
      ...u16(0), ...u16(0), ...u32(crc), ...u32(data.length), ...u32(data.length),
      ...u16(nameBytes.length), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset)
    ]);
    centralChunks.push(central, nameBytes);
    offset += local.length + nameBytes.length + data.length;
  }
  const centralBytes = joinBytes(centralChunks);
  const localBytes = joinBytes(localChunks);
  const end = new Uint8Array([
    ...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(entries.length), ...u16(entries.length),
    ...u32(centralBytes.length), ...u32(localBytes.length), ...u16(0)
  ]);
  return new Blob([localBytes, centralBytes, end], { type: "application/zip" });
}
downloadZipBtn.addEventListener("click", async () => {
  const selected = selectedImages();
  if (!selected.length) return;
  downloadZipBtn.disabled = downloadBtn.disabled = true;
  const entries = [];
  for (let i=0;i<selected.length;i++) {
    try {
      const {blob,ext} = await prepareImage(selected[i]);
      const data = new Uint8Array(await blob.arrayBuffer());
      entries.push({name:`${String(i+1).padStart(3,"0")}-${safeName(selected[i].alt || `shein-image-${i+1}`)}.${ext}`,data});
    } catch(err) { console.warn("ZIP image failed",err); }
    setStatus(`Preparing ZIP: ${i+1}/${selected.length} checked · ${entries.length} ready`);
  }
  if (!entries.length) {
    setStatus("Could not fetch images for ZIP. Try individual downloads.");
    refreshCount();
    return;
  }
  try {
    const zip = buildZip(entries);
    await saveBlob(zip, "SHEIN-Images.zip");
    setStatus(`ZIP download started with ${entries.length} of ${selected.length} images.`);
  } catch(err) {
    console.error(err);
    setStatus("ZIP could not be saved. Check Chrome downloads.");
  }
  refreshCount();
});
