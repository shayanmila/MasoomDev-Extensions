chrome.runtime.onMessage.addListener((message,sender,sendResponse) => {
  if (message?.type !== "SHEIN_OPEN_FLOATING") return;
  (async () => {
    if (!sender.tab?.id) throw new Error("Source tab unavailable");
    await chrome.storage.session.set({sheinSourceTabId:sender.tab.id});
    const existing = await chrome.storage.session.get("sheinWindowId");
    if (existing.sheinWindowId) {
      try {
        await chrome.windows.update(existing.sheinWindowId,{focused:true});
        sendResponse({ok:true}); return;
      } catch (_) {}
    }
    const win = await chrome.windows.create({
      url:chrome.runtime.getURL("popup.html?floating=1"),
      type:"popup",width:440,height:690,focused:true
    });
    await chrome.storage.session.set({sheinWindowId:win.id});
    sendResponse({ok:true});
  })().catch(err => sendResponse({ok:false,error:err.message}));
  return true;
});
chrome.windows.onRemoved.addListener(async id => {
  const saved=await chrome.storage.session.get("sheinWindowId");
  if (saved.sheinWindowId===id) await chrome.storage.session.remove("sheinWindowId");
});
