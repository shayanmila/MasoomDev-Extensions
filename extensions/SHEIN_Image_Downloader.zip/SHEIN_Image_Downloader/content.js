(() => {
  // Sections that never belong to the product being viewed.
  const EXCLUDE = [
    "header", "footer", "nav", "aside",
    "[class*='recommend' i]", "[class*='similar' i]", "[class*='related' i]",
    "[class*='also' i]", "[class*='you-may' i]", "[class*='youmay' i]",
    "[class*='review' i]", "[class*='comment' i]", "[class*='recently' i]",
    "[class*='banner' i]", "[class*='footer' i]", "[class*='header' i]",
    "[class*='swatch' i]", "[class*='color-block' i]", "[class*='product-intro__color' i]",
    "[class*='modal' i]", "[class*='toast' i]"
  ].join(",");

  // Known SHEIN product-gallery containers (main image + thumbnail strip).
  const GALLERY_SELECTORS = [
    "[class*='product-intro__gallery' i]",
    "[class*='product-intro__thumbs' i]",
    "[class*='goods-detail-gallery' i]",
    "[class*='goodsdetail__gallery' i]",
    "[class*='main-picture' i]"
  ].join(",");

  const MIN_SIZE = 40; // ignore tiny icons (rendered smaller than this)

  // SHEIN serves resized copies such as ..._thumbnail_405x552.webp or
  // ..._square_thumbnail_220x293.jpg. Removing the "_thumbnail_WxH" part gives
  // the full-resolution original on the same CDN.
  function toHighRes(url) {
    try {
      const u = new URL(url);
      if (/ltwebstatic|sheincdn|shein/i.test(u.hostname)) {
        u.pathname = u.pathname.replace(/_(?:square_)?thumbnail_\d*x\d*(?=\.[a-z0-9]+$)/i, "");
        u.search = ""; // drop resize/format query params such as ?imformat=...
        u.hash = "";
      }
      return u.toString();
    } catch (_) {
      return url;
    }
  }

  const isExcluded = el => !!el.closest(EXCLUDE);

  // Fallback when no known selector matches: take the biggest visible image near the
  // top of the page (the main product photo) and widen to the column that holds it.
  function heuristicRoot() {
    const vw = window.innerWidth;
    let main = null, best = 0;
    document.querySelectorAll("img").forEach(img => {
      if (isExcluded(img)) return;
      const r = img.getBoundingClientRect();
      if (r.width < 150 || r.height < 150) return;
      if (r.top + window.scrollY > 1400) return;
      const area = r.width * r.height;
      if (area > best) { best = area; main = img; }
    });
    if (!main) return null;
    let root = main.parentElement;
    while (root && root.parentElement && root.parentElement !== document.body) {
      const p = root.parentElement;
      if (p.getBoundingClientRect().width > vw * 0.62) break;
      root = p;
    }
    return root;
  }

  function findScopes(scope) {
    if (scope === "page") return { roots: [document], matched: "page" };
    const found = [...document.querySelectorAll(GALLERY_SELECTORS)]
      .filter(r => !isExcluded(r) && r.querySelector("img"));
    const top = found.filter(r => !found.some(o => o !== r && o.contains(r)));
    if (top.length) return { roots: top, matched: "selector" };
    const h = heuristicRoot();
    if (h) return { roots: [h], matched: "heuristic" };
    return { roots: [], matched: "none" };
  }

  function collectImages(scope) {
    const found = new Map();
    const productOnly = scope !== "page";

    const add = (url, alt = "") => {
      if (!url || typeof url !== "string") return;
      url = url.trim();
      if (url.startsWith("//")) url = location.protocol + url;
      if (url.startsWith("http://")) url = "https://" + url.slice(7);
      if (!/^https?:\/\//i.test(url)) return;
      if (!/\.(jpe?g|png|webp|avif)(?:[?#]|$)/i.test(url) &&
          !/sheincdn|shein|ltwebstatic/i.test(url)) return;
      const original = url;
      url = toHighRes(url);
      // De-duplicate on the high-res URL so thumbnail variants collapse into one entry.
      if (!found.has(url)) found.set(url, { url, fallback: original, alt: (alt || "").trim().slice(0, 140) });
    };

    const { roots, matched } = findScopes(scope);

    roots.forEach(root => {
      root.querySelectorAll("img").forEach(img => {
        if (productOnly) {
          if (isExcluded(img)) return;
          const r = img.getBoundingClientRect();
          if (r.width > 0 && (r.width < MIN_SIZE || r.height < MIN_SIZE)) return;
        }
        add(img.currentSrc || img.src, img.alt || img.getAttribute("title") || "");
        ["data-src", "data-original", "data-lazy-src", "data-img-src"].forEach(attr =>
          add(img.getAttribute(attr), img.alt || "")
        );
        const srcset = img.getAttribute("srcset") || img.getAttribute("data-srcset") || "";
        srcset.split(",").forEach(part => {
          const url = part.trim().split(/\s+/)[0];
          add(url, img.alt || "");
        });
      });

      // Some product galleries render images as CSS backgrounds.
      root.querySelectorAll("[style*='background-image']").forEach(el => {
        if (productOnly && isExcluded(el)) return;
        const style = el.getAttribute("style") || "";
        const matches = style.matchAll(/url\((['"]?)(.*?)\1\)/g);
        for (const match of matches) add(match[2], el.getAttribute("aria-label") || "");
      });
    });

    return { images: Array.from(found.values()), matched };
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "SHEIN_COLLECT_IMAGES") {
      const { images, matched } = collectImages(message.scope);
      sendResponse({ images, matched, pageTitle: document.title });
    }
    return true;
  });
})();
