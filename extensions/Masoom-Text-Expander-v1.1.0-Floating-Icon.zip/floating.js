(() => {
  'use strict';
  if (window !== window.top || document.getElementById('masoom-text-floating-root')) return;
  const root = document.createElement('div');
  root.id = 'masoom-text-floating-root';
  const shadow = root.attachShadow({mode:'closed'});
  const style = document.createElement('style');
  style.textContent = `:host{all:initial}*{box-sizing:border-box}#launcher{position:fixed;right:18px;bottom:110px;width:48px;height:48px;border-radius:50%;border:2px solid white;background:#6046cc;color:white;box-shadow:0 4px 18px #0005;cursor:grab;z-index:2147483647;font:bold 23px system-ui;display:grid;place-items:center;touch-action:none}#panel{position:fixed;right:20px;top:100px;width:330px;height:490px;min-width:260px;min-height:145px;max-width:calc(100vw - 12px);max-height:calc(100vh - 12px);background:#fff;border:1px solid #b9aaf7;border-radius:12px;overflow:hidden;box-shadow:0 8px 36px #0005;z-index:2147483646;display:none;resize:both}#panel.visible{display:block}#head{height:38px;background:#6046cc;color:white;display:flex;align-items:center;justify-content:space-between;padding:0 7px 0 12px;font:600 13px system-ui;cursor:move;user-select:none;touch-action:none}#actions{display:flex;gap:5px}#actions button{border:0;background:#ffffff25;color:white;font:20px system-ui;line-height:1;width:27px;height:27px;border-radius:5px;cursor:pointer}iframe{display:block;border:0;width:100%;height:calc(100% - 38px);background:white}#panel.min{height:38px!important;min-height:38px;resize:none}#panel.min iframe{display:none}@media(max-width:450px){#panel{width:min(330px,calc(100vw - 16px));right:8px}}`;
  const launcher=document.createElement('button');launcher.id='launcher';launcher.textContent='✍';launcher.title='Open Masoom Text Expander';launcher.setAttribute('aria-label','Open Masoom Text Expander');
  const panel=document.createElement('div');panel.id='panel';
  const head=document.createElement('div');head.id='head';
  const name=document.createElement('span');name.textContent='✍ Masoom Text Expander';
  const actions=document.createElement('div');actions.id='actions';
  const mini=document.createElement('button');mini.textContent='−';mini.title='Minimise / Restore';
  const close=document.createElement('button');close.textContent='×';close.title='Close panel';
  actions.append(mini,close);head.append(name,actions);
  const frame=document.createElement('iframe');frame.src=chrome.runtime.getURL('panel.html');frame.title='Masoom Text Expander';
  panel.append(head,frame);shadow.append(style,launcher,panel);
  (document.documentElement||document.body).append(root);
  const key='masoomTextFloatState';
  const state={open:false,min:false,x:null,y:null,w:330,h:490,iconX:null,iconY:null};
  const clamp=(v,min,max)=>Math.max(min,Math.min(v,max));
  const persist=()=>chrome.storage.local.set({[key]:state}).catch(()=>{});
  function fit(){
    state.w=clamp(state.w,260,Math.max(260,innerWidth-12));
    state.h=clamp(state.h,145,Math.max(145,innerHeight-12));
    state.x=clamp(state.x??Math.max(6,innerWidth-state.w-20),0,Math.max(0,innerWidth-state.w));
    state.y=clamp(state.y??100,0,Math.max(0,innerHeight-(state.min?38:state.h)));
    panel.style.left=state.x+'px';panel.style.top=state.y+'px';panel.style.right='auto';
    panel.style.width=state.w+'px';if(!state.min)panel.style.height=state.h+'px';
    launcher.style.left=clamp(state.iconX??innerWidth-66,0,Math.max(0,innerWidth-48))+'px';
    launcher.style.top=clamp(state.iconY??innerHeight-158,0,Math.max(0,innerHeight-48))+'px';
    launcher.style.right='auto';launcher.style.bottom='auto';
  }
  function render(){panel.classList.toggle('visible',state.open);panel.classList.toggle('min',state.min);mini.textContent=state.min?'□':'−';fit();}
  function toggle(){state.open=!state.open;if(state.open)state.min=false;render();persist();}
  mini.addEventListener('click',()=>{if(!state.min){state.h=Math.round(panel.getBoundingClientRect().height);state.min=true;}else{state.min=false;}render();persist();});
  close.addEventListener('click',()=>{state.open=false;render();persist();});
  function draggable(element,isIcon){let start=null,moved=false;
    element.addEventListener('pointerdown',e=>{if(e.button!==0||(!isIcon&&actions.contains(e.target)))return;start={px:e.clientX,py:e.clientY,x:isIcon?launcher.getBoundingClientRect().left:panel.getBoundingClientRect().left,y:isIcon?launcher.getBoundingClientRect().top:panel.getBoundingClientRect().top};moved=false;element.setPointerCapture(e.pointerId);e.preventDefault();});
    element.addEventListener('pointermove',e=>{if(!start)return;const dx=e.clientX-start.px,dy=e.clientY-start.py;if(Math.abs(dx)+Math.abs(dy)>4)moved=true;if(!moved)return;if(isIcon){state.iconX=clamp(start.x+dx,0,innerWidth-48);state.iconY=clamp(start.y+dy,0,innerHeight-48);}else{state.x=clamp(start.x+dx,0,Math.max(0,innerWidth-panel.offsetWidth));state.y=clamp(start.y+dy,0,Math.max(0,innerHeight-panel.offsetHeight));}fit();});
    element.addEventListener('pointerup',()=>{if(!start)return;start=null;if(moved)persist();if(isIcon&&!moved)toggle();});
    element.addEventListener('pointercancel',()=>{start=null;});
  }
  draggable(launcher,true);draggable(head,false);
  new ResizeObserver(()=>{if(!state.open||state.min)return;const r=panel.getBoundingClientRect();if(Math.abs(state.w-r.width)>1||Math.abs(state.h-r.height)>1){state.w=Math.round(r.width);state.h=Math.round(r.height);persist();}}).observe(panel);
  window.addEventListener('resize',()=>{fit();persist();});
  chrome.storage.local.get(key).then(r=>{Object.assign(state,r[key]||{});render();}).catch(render);
  chrome.runtime.onMessage.addListener(msg=>{if(msg?.type==='MASOOM_TEXT_TOGGLE_FLOAT'){toggle();}});
})();
